#   Bitwise Operators => Art Vergleichsoperator auf Bitlogikebene
#   Bei Vergleich brauchen wir zwei Daten
#   Auf Bitlogikebene vergleichen wir die die Bits von zwei versc. Bytes an der jew. Bitposition

#   &     name = "ampersand"    => Bitwise AND  => Result = 1 if both Bits = 1  
#   |     name = "disjunction"  => Bitwise OR   => Result = 1 if one or both Bits = 1 (also mindestens einer muss 1 sein)
#   ^     name = "exclusion"    => Bitwise XOR  => Result = 1 if only one of teh compared Bits = 1 (nur einer verglichenen Bits darf = 1 sein)

# ... Bekommen wir keine 1 als Ergbenis, dann erhalten wir 0 als Ergebnis (je Bitposition)


# AND (&) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# BYTE A        1       0       1       1       1       0       1       0
# BYTE B        1       1       1       0       1       0       1       0
# Resultat      1       0       1       0       1       0       1       0       => 128 + 32 + 8 + 2 = 170

# OR (|)  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# BYTE A        1       0       1       1       1       0       1       0
# BYTE B        1       1       1       0       1       0       1       0
# Resultat      1       1       1       1       1       0       1       0       => 128 + 64 +32 + 16 +8 + 2 => 250

# XOR (^) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# BYTE A        1       0       1       1       1       0       1       0
# BYTE B        1       1       1       0       1       0       1       0
# Resultat      0       1       0       1       0       0       0       0      => 80
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 



# Kleiner automatischer Übungsaufgaben-Generator (max. 8-Bit !)

import random
ops = ["&", "|", "^"]

def checkBin(*args):
    for i in range(len(args)):
        if i == 2: input()
        strBin = bin(args[i])[2:]
        strBin = (8 - len(strBin)) * " " + strBin
        strBin = ' '.join(list(strBin))
        print(f"{strBin}" + " => ", args[i])

while True:
    a = random.randrange(0, 128)
    b = random.randrange(0, 128)
    o = random.choice(ops)
    calc = f"{a} {o} {b}"    # zB "56 & 3" oder "12 | 128"
    print(calc)
    result = eval(calc)
    checkBin(a, b, result)
    print("- " * 30)
   
