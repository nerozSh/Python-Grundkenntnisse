#   Bitwise operators
#   <<  Left-Shift  (Linksverschiebung)     =>  Ergebnis für und als Integer => entspricht Input * 2
# => Verschiebt die Bits in dem Byte alle jeweils um eine Bitposition nach Links
#   >>  Right-Shift (Rechtsverschiebung)    =>  Ergebnis für und als Integer => entspricht Input // 2
# => Verschiebt die Bits in dem Byte alle jeweils um eine Bitposition nach Rechts

# LeftShift (<<)  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# BYTE                          1       1       1       0       1       0       => Ergebnis 58
# Resultat              1       1       1       0       1       0       0       => Ergebnis 116
# => Neues Bit an BitPos Null ist immer = 0 denn Ergebnis aus Multiplikation mit Int ist immer gerade
#                                                               ?>>>>>  0

# RightShift (>>) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# BYTE                          1       1       1       0       1       1       => Ergebnis 59
# Resultat                      0       1       1       1       0       1       => Ergebnis 29
# => Das Bit an BitPos 0 fällt weg, da es keine niedriegere Position als BitPos 0 gibt
# => Deshalb resultiert ein Rightschift auch immer in eine Integer Division => Dezimalstelen fallen weg
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# Kleiner automatischer Übungsaufgaben-Generator (max. 8-Bit !)

import random
ops = ["<<", ">>"]

def checkBin(*args):
    for i in range(len(args)):
        strBin = bin(args[i])[2:]
        strBin = (8 - len(strBin)) * "0" + bin(args[i])[2:]
        print(f"{' '.join(list(strBin))}" + " =>", args[i])
        if i == 0: input()
        
while True:
    a = random.randrange(0, 64)
    o = random.choice(ops)
    b = random.randrange(1, 3)
    calc = f"{a} {o} {b}"
    print(calc)
    result = eval(calc)
    checkBin(a, result)
    print("- " * 30)
 #   Bitwise operators
#   ~  (tilde) - bitwise negation  => gekhrt alle Bits um (d.h. wenn 0 dann 1 bzw wenn 1 dann 0)

# Negate (~)  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# BYTE          0       0       1       1       1       0       1       0
# Resultat      1       1       0       0       0       1       0       1
