# 1 Bit = 0 oder 1  (Grundegende Computersprache)
    # Hat damit zu tun, das auf Schaltkreisebene (Hardware) Elektrische Ströme ein und ausgeschaltet werden können
    # Je nach Routing können so unterschoedliche Widerstände und Stromflusstärken ermöglicht werden
    # Diese wiederrum können bei Parallelisierung bzw. Staffelung auch zu Zahlenräumen interpretierbar gemacht werden

# 1 Byte = (normally) 8 Bit.
# 1 Byte (mit 8 Bit) kann Werte zwischen 0 bis 255 darstellen (d.h insgesamt 256 Werte inkl. 0)

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# Von rechts nach links lesen
#   All Off     0       0       0       0       0       0       0       0
#   All On      1       1       1       1       1       1       1       1
#   2** BitPos  7       6       5       4       3       2       1       0 
#   Ergebnis    128     64      32      16      8       4       2       1 
# -----------------------------------------------------------------------
#   Summe       255 == 256 == 2**8 - 1

# Durch an/ausschalten von Bits lassen sich alle Werte im Spektrum darstellen
#
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
#
# Beispiel-A    1       0       1       0       1       0       1       0
# Ergebnis    128       0      32       0       8       0       2       0
#
# Summe == 170
#
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
#
# Beispiel-B    0       1       0       1       0       1       0       1
# Ergebnis      0      64       0      16       0       4       0       1
# Summe == 85
# 
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# Beispiel-C    1       1       0       0       0       0       1       1
# Ergebnis    128      64       0       0       0       0       2       1
# Summe == 195
#
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 



# Kleiner automatischer Übungsaufgaben-Generator (max. 8-Bit !)

vals = [128, 64, 32, 16, 8, 4, 2, 1]

import random

def checkBin(a):
    strBin = bin(a)[2:]
    strBin = (8 - len(strBin)) * "0" + bin(a)[2:]
    print("  " + f"{'   '.join(list(strBin))}" + "  => ", "???")
    input()
    result = [(" " * (3 - len(str(int(v) * vals[i])))) + str(int(v) * vals[i]) for i, v in enumerate(strBin)]
    print(' '.join(result), " => ", a, "\n")
   
while True:
    a = random.randrange(0, 256)
    checkBin(a)
    print("- " * 30)
    input()
