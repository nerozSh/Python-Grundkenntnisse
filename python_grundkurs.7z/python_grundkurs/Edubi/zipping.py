# Die .zip() function (Class)
# Ziel: Verschiedene  Sequenzen mappen

a = ["x", "y", "z"]
b = [1, 2, 3]

result = zip(a, b)
print(result)

# MERKE => Ergebnis von zip ist noch keine eigenständige Sequenz => Muss noch gecastet werden

castedResult = list(result)
print(castedResult)

# Erstellt uns Liste aus Tuplen => Anzahl der Tuple = Anzahl der Items in den Übergebenen Listen
# In jener Reihenfolge in der wir, die Seqwuenzen an .zip() übergeben: => wird die Reihenfolge der Werte in den Tuples angelegt

a = ["x", "y", "z", "a"]
b = [1, 2, 3]

castedResult = list(zip(a, b))
print(castedResult)

# Übergeben wir unterschiedlich lange Sequenzen an .zip() => dann entspricht die ANzahl der Tuple durch zip =>x der Anzahl der items in der kürzesten Sequenz 

a = ("x", "y", "z", "a")
b = [1, 2, 3]

castedResult = dict(zip(a, b))
print(castedResult)

# Guter Use Case, um mit SEHR WENIG CODE => mehrere eindimensionale Datenreihen zu mehrdimensionalen Dictionaries verbinden
    # zB aus unterschiedlichen Datenquellen Coordinatensysteme abstrakt repräsentieren 

x = ("x", "y", "z", "a")
y = [1, 2, 3]
z = [True, False, None, "a", 7, 8.1]

castedResult = dict(zip(a, b))
print(castedResult)

# => Reicht nicht aus um mehrdimensionale Datenrepräsentation darzustellen, die mehr als zwei DImensionen haben
# Dictionaries => key-value-PAIRS !!

subCast = list(zip(y, z))
finalCast = dict(zip(x, subCast))
print(finalCast)

finalCast = dict(zip(x, list(zip(y, z))))
print(finalCast)