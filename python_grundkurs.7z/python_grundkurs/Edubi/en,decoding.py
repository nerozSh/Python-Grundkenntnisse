### ZEICHENSTANDARDS UND EN/-DECODING

###################################################################################################

# ASCII (American Standard Code for Information Interchange)

# Sehr alt, sehr begrenzt
# Nur 128 Zeichen: A–Z, a–z, 0–9, Sonderzeichen
# Jeder Buchstabe = 1 Byte
# Kein "ä", "ß", "é", "€", Emoji usw.

myString = "Hallo"
inASCII = myString.encode("ascii")
print(inASCII)


myString = "Häöü?ßllo"
try:
    inASCII = myString.encode("ascii")
    print(inASCII)
except Exception as e:
    print(e)


###################################################################################################

# UTF-8 (Unicode Transformation Format 8-bit)

# Aktuell
# Unterstützt ALLE Zeichen weltweit (Unicode)
# Dynamische Länge: 1 bis 4 Bytes pro Zeichen
# Kompatibel mit ASCII (die ersten 128 Zeichen sind gleich)
# Zeichen mit Umlauten, Emojis, Kyrillisch, Arabisch, Chinesisch usw.

myUTF8 = myString.encode("utf-8")
print(myUTF8)
myUTF8 = myUTF8.decode("utf-8")
print(myUTF8)


###################################################################################################

# Codepoints => Unicode-Standard (ISO/IEC 10646)

# Weltweit eindeutig (z.B. 'ä' = U+00E4 = 228).
# Weder ASCII noch UTF-8 => ord() und chr() geben keine Bytes, sondern Codepoints (als Integer)
# Jeder Buchstabe/Symbol bekommt eine eindeutige Nummer (Codepoint).
# ord() und chr() arbeiten mit Unicode-Codepoints.
# Was genau angezeigt wird, hängt aber z.T. vo Font und System ab (Rendering).
# Unicode gibt nur den Codepoint vor (z.B. U+0001).
# Manche Fonts zeigen für U+0001 einen Smiley.
# Andere zeigen nichts oder ein leeres Rechteck.
# Nicht jeder Codepoint ist "sichtbar" oder "druckbar".

# Steuerzeichen in Unicode
# U+0001 ist z B. ein Steuerzeichen (Start of Header).
# Ursprünglich für Drucker, Terminals, Kommunikation gedacht.
# Heute meist unsichtbar, aber oft in Dateien, Protokollen, Terminals noch aktiv.
# Viele Zeichen werden von modernen Apps ignoriert oder als Sonderfall behandelt.

'''
Hier einige Steuerzeichen (U+0000–U+001F, + U+007F):
Code	Kürzel	Bedeutung
0000	NUL	Nullzeichen (Ende o. Trennung)
0007	BEL	„Bell“ – macht Ton (🔔)   => Sofern Terminal Bell unterstützt
0008	BS	Backspace (←)
0009	TAB	Horizontal Tab (Tabulator)
000A	LF	Line Feed (Zeilenumbruch, Unix)
000B	VT	Vertikaler Tab
000C	FF	Form Feed (Seitenvorschub)
000D	CR	Carriage Return (Zeilenanfang, Windows mit LF)
001B	ESC	Escape – startet Steuersequenz
007F	DEL	Delete – Zeichen löschen
'''
# EInige direkte Python Äquivalente zu Steuerzeichen:
# \n (LF): neuer Absatz (z. B. in console.log)
# \r\n: Windows-Zeilenumbruch
# \t: Einrückung (Tab)
# \x1b[31m: Terminal-Farbe (ANSI-Escape mit ESC)
# print("\a")  # \a = BEL (ASCII 7)

# Kleine Spielerei mit Steuerzeichen:
for i in range(30, 38):
    text = "Hallo"
    print(f"\x1b[{i}m{text} {i}\x1b[0m", end= ', ') 

print("\n")
for i in range(40, 48):
    text = "Hallo"
    print(f"\x1b[{i}m{text} {i}\x1b[0m", end= ', ') 
    
  
# Verwendung von Unicode in Python:

myChar = "a"
ordinal = ord(myChar)
print(ordinal)

myOrd = 98
myChar = chr(1)
print(myChar)

import time

currChar = "a"
currOrd = 0

for i in range(500):
    #currOrd = ord(currChar)
    currChar = chr(currOrd)
    print(currChar, currOrd)
    currOrd += 1
    time.sleep(0.25)

    
###################################################################################################
    
# Codepage: Lokale Zuordnung

# Alte Zeichensätze – z. B. ISO-8859-1, Windows-1252; meist auf 256 Zeichen begrenzt.
# Nicht standardisiert weltweit – unterschiedliche Bedeutungen für gleiche Bytewerte (z.B. 0xE4 ist nicht überall „ä“).
# Abhängig vom Kontext (Sprache/Region) – z. B. CP1251 (kyrillisch), CP437 (DOS
# Inkompatibel untereinander – Copy-Paste oder Dateilesen führt oft zu „�“ oder falschen Zeichen.
# Wurde durch Unicode ersetzt – Unicode löst das Codepage-Chaos durch globale Einheitsnummerierung.

