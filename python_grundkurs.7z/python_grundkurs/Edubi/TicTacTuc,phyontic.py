

import random

board = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]                           # Logisches Spielfeld

line = "-" * 25                                                     # Horizontale Trennlinie
space = "|" + (' ' * 7 + '|') * 3                                   # Padding

sign = "X" if random.random() < 0.5 else "O"                        # Random welcher Spieler startet (und toggle für Move global initiieren)


def display(b):                                                     # Visuelles Spielfeld bauen 
    print("\33c", end="")                                           # Console clearen
    print(line)                                                     # Top Line ausgeben
    for row in b:
        fill = '| ' + ' '.join(f"  {x}   |" for x in row)           # "| " + in der Reihe 3 Zellen mit Feldnummer bauen
        print(f"{space}\n{fill}\n{space}\n{line}")                  # Gesate Reihe mit Padding ausgeben


def getFreeFields(b):
    return list(filter(lambda x: isinstance(x, int), sum(b, [])))   # Feldnummern nicht belegter Zellen als Liste zurückgeben
    
def writePick(cell, sign): 
    board[(cell -1) // 3][(cell -1) % 3] = sign                     # Feldnummer in Indizies (Reihe, Spalte) umrechnen, und logisches Spielfeld updaten


def getWinner(b):
    if b[0][0] == b[1][1] == b[2][2]: return b[1][1]                # Gewinner in der Diagonalen \
    if b[0][2] == b[1][1] == b[2][0]: return b[1][1]                # Gewinner in der Diagonalen /
    for i in range(3):
        if b[i][0] == b[i][1] == b[i][2]: return b[i][1]            # Gewinner in der Horizontalen
        if b[0][i] == b[1][i] == b[2][i]: return b[1][i]            # Gewinner in der Vertikalen
    return ""                                                       # Noch kein Gewinner


def playerMove(b):
    while True:                                                     # Fußgesteuerte Schleife bis gültige User Eingabe
        try:
            pick = int(input("Your Turn (1-9):"))                   # Versuch User Eingabe als int zu casten
            if pick in getFreeFields(b):                            # Ist User Eingabe in noch verfügbarem Feld?, dann...
                writePick(pick, "O")                                # User Eingabe in logisches Spielfeld schreiben
                break                                               # Loop nur bei gültiger User Eingabe beenden
        except: pass                                                # Universal alle ungültigen User Eingaben abfangen
        print("Not Valid")                                          # User über Ungültige EIngabe informieren, wenn nicht vorher break eintritt


def botMove(b):
    pick = random.choice(getFreeFields(b))                          # Zufallsfeld ais noch verfügbaren Feldern wählen
    writePick(pick, "X")                                            # Bot Spielzug in logisches Spielfeld schreiben


def move(b, sign):
    if sign == "O": playerMove(b)                                   # User Spielzuglogik abrufen wenn User dran ist
    else: botMove(b)                                                # User Spielzuglogik abrufen wenn User nicht dran ist
    display(b)                                                      # Visuelles Spielfeld updaten
    winner = getWinner(b)                                           # Ergebnis aus getWinner zur Prüfung returnen (X / O / "")
    if winner: return winner                                        # Erst check ob es schon Gewinner gibt, wenn ja diesen returnen
    if len(getFreeFields(board)) == 0: return "draw"                # Wenn nicht, dann erst checken ob unentschieden ist (ob keine freien Felder mehr übrig)
    

display(board)                                                      # Visuelles Spielfeld initiieren

while True:                                                         # Fußgesteuerte Endlos-Schleife bis Spiel vorbei
    sign = "O" if sign == "X" else "X"                              # Spieler Zug Toggle (immer abwechselnd)
    result = move(board, sign)                                      # Nächsten Zug starten => Spielfeld und Spieler übergeben
    if result:                                                      # Wenn Ergebnis nicht O / X / draw  (kann nur leer sein), dann ..
        print(f"Game ended: {result.title()}" if result == "draw" else f"Player {result} won!")  # Ergebnis mit Grammatik ausgeben
        break                                                       # Endlosschleife beenden, wenn Spiel zu ende ist




# Weitere denkbare Funktionen?

        # Steht Draw schon früher fest?
        # Bot "intelligenter" machen => Ziel zu gewinnen
        # Schon früher klar dass Bot gewinnt?
        # Letzte Eingabe des Users einfärben
        # Mehr Spielfelder 
        # Mehr Spieler




'''
Zahlenreihen als Hilfestellung, um anhand der Feldnummer die Reihen- und Spaltenindizies zu ermitteln (siehe Funktion: writePick())
Input           (cell -1) // 3      (cell -1) % 3
cell            row                 col
1               0                   0
2               0                   1
3               0                   2
4               1                   0
5               1                   1
6               1                   2
7               2                   0
8               2                   1
9               2                   2
'''