import random, time
from shutil import get_terminal_size                                # Zum Ermitteln der Terminalbreite

chars = list("アイウエオカキクケコサシスセソ0123456789")               # Zeichenliste mit Katakana + Zahlen
width = get_terminal_size().columns                                 # Holt aktuelle Breite des Terminals

columns = [0] * width                                               # Initialisiert eine Liste für jede Spalte (Position des "Regens")

while True:                                                         # Endlosschleife für Matrix-Effekt
    print("\x1b[2J")                                                # ANSI: Bildschirm löschen
    print("\x1b[H")                                                 # ANSI: Cursor nach oben links setzen

    for y in range(20):                                             # Schleife für 20 vertikale Zeilen
        line = ""                                                   # Initialisiert aktuelle Zeile
        for i in range(width):                                      # Durch jede Spalte iterieren
            if random.random() > 0.97:                              # Zufällig Spalte "resetten" (Neustart oben)
                columns[i] = 0
            if columns[i] < y:                                      # Noch kein Zeichen an dieser Position? dann ...
                line += " "                                         # Leerzeichen einfügen
            else:
                line += f"\x1b[1;32m{random.choice(chars)}\x1b[0m"  # Fett + grün + zufälliges Zeichen aus Liste
        print(line)                                                 
    columns = [c + random.randint(0, 2) for c in columns]           # Spalten individuell "fallen" lassen
    time.sleep(0.01)  