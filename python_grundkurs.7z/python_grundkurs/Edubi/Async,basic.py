# BASICS ASYNCHRONE PROGRAMMIERUNG

    # Asynchron = Mehrere Prozesse (z.B. Funkionen können parallel/gleichzeitig verarbeitet werden)
    # Dadurch können wir mehere Prozesse schneller zum Abschluss bringen => Massive Performanzsteigerung und Skalierbarkeit
    # Unerlässlich in Verbindung mit Datenbanken, größeren Softwares, SaaS, Apps mit Nutzern

import asyncio 
import time 

##############################################################################

async def myTask(num):      # wir wollen diese Function asynchron aufrufen
    await asyncio.sleep(5)  # Latenz, um lange/komplexe Funktionen zu simuliereen
    # time.sleep() ==> Problem => Weil würde dazu führen, dass Auch die äußere asynchrone Logik, unterbrochen bzw sich synchron verhält => Funktionsaufruf würde warten
    # daher zeitliche Methodenverwendung auf asyncio, damit außerer Funktionsaufruf, nicht durch ungewünschte Synchronität gestört wird
    return num + 100

def myTask2(num):           # Kein async zugeweisen => normale Funktion. Diese können wir mit der asyncio.to_thread() Methode aber trotzdem asynchron verwenden (aber mit Limits)
    for i in range(5):
        time.sleep(1)       # Da keine async Function, nutzen wir hier das normale time.sleep()
        print(i)
    return num + 100

##############################################################################

async def main():

    # Beispiel 1: Synchroner Aufruf einer asynchronen Funktion 
    result1 = await myTask(1)   # => Wir warten bis Funktion fertig ist, sodass wir result bekommen
    print("Bsp1:", result1)

    print("- " * 30)

    # Beispiel 2a: Asynchroner Aufruf: ABER So geht's nicht in Python !
    result2a = myTask(2)          # Funktion wird NICHT ausgeführt
    print("Bsp2a:", result2a)     # Daher kein Ergebnis, sondern nur Cache ID der Funktion (coroutine) in Cache

    print("- " * 30) 

    # Beispiel 2b: Task starten, läuft aber im Hintergrund (asynchron => parallel)
    asyncio.create_task(myTask(1))              # Ohne abrufen des Return Wertes, sprechen wir vom sog. "Fire & Forget"
    result2b = asyncio.create_task(myTask(1))   # Wir warten hier NICHT auf Fertigstellung der Funktion (Code in nächster Zeile läuft sofort weiter)
    print("Bsp2b", result2b)                    # Daher ist auch kein Ergebnis vorhanden außer => Der noch nicht fertiggestellte Task (Thread) =>x Coroutine im Cache

    print("- " * 30) 

    # Beispiel 3: Parallelisierung => mit .gather() Sammeln und Entpacken (Asynchrone Ausführung mehrerer Funktionsaufrufe)
    myTuple1 = await asyncio.gather( # Wartet bis alle parlellel aufgerufenen Funktionen fertig sind, und gibt uns alle Return in Tuple zurück
        myTask(1),
        myTask(2),
        myTask(3),
        myTask(4),
        myTask(5)
    )
    a, b, c, d, e = myTuple1
    print("Bsp3:", a, b, c, d, e)
    # Ergebnis: Wir warten nicht 5 x 5 Sekunden, sondern 1 x 5 Sekunden bis alle 5 Funktionen durchgelaufen sind (Parallel)
    # Trotzdem stehen uns die Return Werte aller aufgerufenen Funktionen zur Verfügung. 

    print("- " * 30) 

    # Beispiel 4: .gather() und Loop
    myTuple2 = await asyncio.gather(*(myTask(i) for i in range(1, 100)))
    print("Bsp4:", myTuple2)
    

    # Ergebnis von Pending Task aus Beispiel 2b nun vorhanden ???
    if result2b.done():
        print("Bsp2:", result2b.result())  # Yes

    print("- " * 30) 

    # Beispiel 5: Verwenden der .to_thread() Methode
    myList3 = await asyncio.gather(  
        asyncio.to_thread(myTask2, 1000)       # mit .to_thread() können wir nicht asynchrone Funktionen trotzdem asynchron ausführen
    )
    print("Bsp5:", myList3) 

    print("- " * 30) 

    # Beispiel 6: Verwenden der .to_thread() Methode inkl Funktionsaufruf via Schleife
    myList4 = await asyncio.gather(*(asyncio.to_thread(myTask2, i) for i in range(1, 15)))
    asyncio.sleep(6)
    print("Bsp6:", myList4)
    # Fazit: Die Limits der asynchronen Verwendung synchroner Funktionen via .to_thread() werden hier deutlicher
    # 12 Funktionsaufrufe werden parallelisiert. Die übrigen 2 werden in einer Folgeiteration parallelisiert.

    
    
##############################################################################

# Gesamten Prozess so abrufen, dass dieser zur asynchronen Verarbeitung fähig ist
asyncio.run(main())         



'''
Szenario                                await/async         to_thread()
Alte Libraries ohne async               geht nicht          work around via to_thread() OK aber limitiert    
CPU-lastige Berechnungen                nicht empfohlen     eher empfohlen (oder multiprocessing mit einer anderen Library)
> 10K Aufrufe                           OK                  Stack Overflow Risiko
'''

# Was ist ein Stack Overflow?
# Wenn dieselbe Funktion (ohne eigene Instanzen) mehrfach aufgerufen wird und ihr Limit für Warteschlange/Mehrfachverarbeitung erreicht

