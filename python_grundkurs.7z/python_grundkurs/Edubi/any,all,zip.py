nums = [1, 2, 3, 4]
print("Sind ALLE Zahlen größer als 2 ?")

isAnyLarger2 = True 
for i in nums:
    if i <= 2:
        isAnyLarger2 = False 
        break
print(isAnyLarger2)

# BESSER SO 
isAnyLarger2 = len([x for x in nums if x > 2]) == len(nums)
print(isAnyLarger2)

# AM BESTEN SO 
isAnyLarger2 = all(x > 2 for x in nums)
print(isAnyLarger2)

# Statt selbst einen loop für jegliche Prüfungen dieser Art vor zu nehmen ... 
# => können wir mit all() die Prüfung z.B. direkt in eine if schreiben und das Ergebnis auf Basis dessen weiterverarbeiten 

# zB if all(x > 2 for x in nums):  ....



print("- " * 30)


nums = [1, 2, 3, 4]
print("Ist irgendeine Zahl größer als 2 ?")

isAnyLarger2 = False
for i in nums: 
    if i > 2:
        isAnyLarger2 = True
        break

print(isAnyLarger2)

# BESSER SO 
isAnyLarger2 = len([x for x in nums if x > 2]) > 0
print(isAnyLarger2)

# AM BESTEN SO 
isAnyLarger2 = any(x > 2 for x in nums)
print(isAnyLarger2)



print("- " * 30)



nums1 = [1, 2, 3, 4, 5]
nums2 = [1, 3, 5, 7, 9]

isAnyNums1InNums2 = False 
for i in nums1:
    for j in nums2: 
        if i == j: 
            isAnyNums1InNums2 = True 
            break 
    if isAnyNums1InNums2:
        break
print(isAnyNums1InNums2)

# BESSER SO 

isAnyNums1InNums2 = len(set(nums1 + nums2)) <= len(nums1 + nums2)
print(isAnyNums1InNums2)

# NOCH BESSSER SO 

isAnyNums1InNums2 = len([x for x in nums2 if x in nums1]) > 0
print(isAnyNums1InNums2)

# AM BESTEN SO 
isAnyNums1InNums2 = any(x in nums1 for x in nums2)
print(isAnyNums1InNums2)

if any(x in nums1 for x in nums2):
    print(True) 
    # .... sonstiger Code
else: 
    pass
    # sonstiger code => zB ganz anderes Modul aufrufen


# Übereinstimmungen auflisten
matches = [x for x in nums2 if x in nums1]
print("matches", matches)



# Zusatzinfo: 
from collections import Counter
# Ziel => Häifigkeit aller Einträge als Dictionary ausgeben
myString = "Hallo Welt, wie geht es Dir denn heute eigentlich so hey? :-)"
countEachEntry = Counter(myString)
print("countEachEntry", countEachEntry)

# Übergeordnete Sortierungshieerrarchie: Values in absteigender Häufigkeits-Reihenfolge
# Untergeordnete Sortierungshierarchie:  Key by default aufsteugend in natürlicher Char-Reihenfolge 