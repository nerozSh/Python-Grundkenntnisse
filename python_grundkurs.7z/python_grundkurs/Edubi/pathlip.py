from pathlib import Path                            # Importiert Path-Klasse für Pfad-Handling

f = Path("my_folder")                               # Erstellt Path-Objekt für Ordner "my_folder" der im root liegt

myFiles = list(f.glob("*.txt"))                     # Sucht alle .txt-Dateien im Ordner (* = jegliche string die vor .txt steht)

for file in myFiles:                                # Schleife über alle gefundenen .txt-Dateien
    text = file.read_text()                         # Liest Inhalt der Datei in Iterationsschritt als Text
    print("text", text)                       
    file.write_text(f"Hallo Welt: {file}")          # Überschreibt Datei mit neuem Text

f.mkdir(exist_ok=True)                              # Erstellt Ordner, falls er noch nicht existiert

for i in range(1, 11):
    file = f / f"{i}.txt"                           # Pfad zu Datei "1.txt" bis "10.txt"
    if not file.exists():                           # Falls Datei nicht existiert ... dann:
        file.write_text(f"Hallo Welt: {i}.txt")     # schreibt neuen Text in Datei
    else:
        print("Datei existiert bereits => skipped") # Hinweis ausgeben, wenn Datei schon existiert
        