import asyncio
import time


async def task(num):
    await asyncio.sleep(1)
    return num*100
task(2)
  
def show(name,*skills,*skillwitoutprogress):
    print(f"hello {name}")
    for skill in skills:
        print(f"skill")

     for key,value in skillwitoutprogress:
        print()