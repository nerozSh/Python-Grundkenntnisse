# args = Arguments
# => beliebig viele positional arguments => Tuple

def myFunc1(*args):
    print(args)
    print(type(args)) # Tuple
    print(args[0], args[1], args[2])

myFunc1(1, 2, 3)


print("\n")


# kwargs = Keyword Arguments
# => beliebig viele keyword arguments => Dictionary

def myFunc2(**kwargs):
    print(kwargs)
    print(type(kwargs)) # Dict
    print(kwargs["a"], kwargs["b"], kwargs["c"])

myFunc2(a = 1, b = 2, c = 3)


print("\n")

# args und kwargs

def myFunc3(*args, **kwargs):
    print(args) 
    print(kwargs) 

myFunc3(1, 2, 3, 4, 5, a = 1, b = 2, c = 3)



# Use Cases:

    # Wenn man viele Daten übergeben muss
        # zB wenn nicht klar ist, ob bzw. wie beständig alle der Daten verwendet werden müssen
        # zB wenn wir Reihenfolge bei der Übergabe ändern

    # Parameter flexibel halten
        # zB wenn man mit daten-intensiven APIs arbeitet und die Daten verarbeiten möchte
            # => Datenstrukturen von API's können geupdatet / geändert werden 
        # Wenn man selbst eine API baut oder eine Library 

    # Code sparen
        # Wir brauchen keine extra-zeilen um die Daten vorher manuell in Tuples bzw dicts zu wrappen 
        # man macht den Funktions-Header übersichtlicher

    # Best Practise




# Funktioniert auch bei Constructors im OOP

class TestyTest:

    # Wir können auch einzelne Paramater zusätzlich zu args und kwargs verwenden
    # Die Einzelparameter müssen allerdings am Anfang stehen => (param1, param2 ... , *args, **kwargs)
    # Use Case für Einzelparameter im Verbindung mir args und kwargs wären zB Userdaten => (userID, *args, **kwargs)
    def __init__ (self, id, *args, **kwargs):   
        print(args) 
        self.id = id
        self.a = args[0]
        self.b = args[1]
        self.c = kwargs["c"]
        self.d = kwargs["d"]
        self.e = kwargs["e"]
        self.f = kwargs["f"]
        
        
testyTest1 = TestyTest(1, 2, 3, c = "hallo", d= 4, e = 5, f = 6)

print(testyTest1.id)
print(testyTest1.a)
print(testyTest1.b)
print(testyTest1.c)
print(testyTest1.d)
print(testyTest1.e)
print(testyTest1.f)