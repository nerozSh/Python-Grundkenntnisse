import random as rd
import time as tm

class User:

    def __init__(self):
        self.email      = ""
        self.password   = ""
        self.verified   = False 
        self.logged     = False


    def signup(self):
        print("Sign Up Now & Access All Benefits!")
        self.email = input("E-Mail:")
        self.password = input("Password:")
        self.auth()


    def auth(self, attempts = 3):

        attempts -= 1
        systemtoken = str(rd.randrange(100_000, 999_999))                # Generate random number of 6 figures as token simulation
        usertoken = input(f"Please verify the token ({systemtoken})")

        try:
            if systemtoken == usertoken:
                self.verified = True
                print("Yayyy: Your are successfully verified :-)")
            else:
                raise Exception("Sorry, token not valid")

        except Exception as e:
            print(e)
            if attempts > 0:
                self.auth(attempts)
            else:
                print("Exceeded 3 Attempts. Please try again later")
            

    def login(self, attempts: int = 3):

        print("Login with Your credentials:")
        attempts -= 1

        try:
            usermail = input("E-Mail:")
            userpassword = input("Password")

            if usermail != self.email:
                raise Exception("User does not exist")
            
            if userpassword != self.password:
                raise Exception("Wrong Password")
            
            self.logged = True

            print("Successfully logged in")
            print("To logout, please close the terminal ;-)")
            self.timeout()

        except Exception as e:
            print(e)
            if attempts >= 0:
                self.login(attempts)
            else:
                print("Exceeded 3 Attempts. Please try again later")


    def timeout(self):
        tm.sleep(5)
        print("Security logout in ...")
        for i in range(5, 0, -1):
            tm.sleep(1)
            print(i)
        self.logout()


    def logout(self):
        self.logged = False
        print("You're logged out")



###############################################################################


class AdminUser(User):                  # Bei Unterklassen müssen wir den Klassennamen der Oberklasse als Parameter im Header ansteuern, statt das Wort "self"

    def delUser(self, user): 
        print("Following User to be deleted", user.email)
        confirm = input("Sure you want to delete this user? (y/n)")
        if confirm == "y":
            try:
                del user
                try:
                    print(user)
                    print("user was not deleted")
                except Exception as e2:
                    if "cannot access local variable" in str(e2) or type(e2) == NameError:
                        print("user was successfully deleted from cache")
                        return True
                    else:
                        print("e2", e2)

            except Exception as e1:
                print("e1", e1)

        elif confirm == "n":
            print("ok user will not be deleted")

        else:
            print("invalid input")

        return False


###############################################################################
