from oopuser import User, AdminUser                 # Oberklasse und Unterklasse aus unserem Modul importieren

users = []                                          # Leere Liste initiieren, um damit wir dynamisch die Referenzen zu unseren User Objekte nachhalten können, um später auf diese zugreifen zu können 
    
for i in range(1, 2):                               # Schleife in der wir dynamisch User Instanzen erstellen
    user = User()                                   # User Instanz erstellen
    users.append(user)                              # Referenz zu unserer User Instanz in unsere Liste ablegen
    user.signup()                                   # Signuo Prozess durchführen

print("\n")

for u in users:                                     # Durch unsere Liste mit den Referenzen zu den User Instanzen loopen
    if isinstance(u, User):                         # Prüfen ob es sich hinter der Referenz wirklich eine Instanz der Klasse 'User' befindet 
        print(
            hex(id(u)), "\n",                       # Storage Slot Id der User Instanz als Integer fetchen und als hex casten
            u.email,    "\n",
            u.password, "\n",
            u.verified, "\n",
            u.logged,   "\n"
        )
        
        
##########################################################################

# Ziel: User löschen und prüfen ob Löschen erfolgreich was

lenUsersListPre = len(users)                        # Länge der Liste checken um die Anzahl der Referenzen vor und nach dem Löschen vergleichen zu können 
print(lenUsersListPre)

slotOfUser = hex(id(users[0]))                      # Storage ID speichern, um später zu beweisen das die ID selbst trotz Löschung des Storage Inhalt noch vorhanden ist

admin1 = AdminUser()                                # AdminUser via Unterklassen erstellen, der den ersten User löschen soll
admin1.signup()                                     # Signup für AdminUser (Signup Methode hat Unterklasse von der Oberklasse geerbt)
admin1.delUser(users[0], users)                     # Wir rufen die Löschfunktion auf, und nehmen in 'wasDeleted' True bzw False entgegen um hier mit der info ob User Instanz gelöscht wurde weiterzuarbeiten


print(users[0].email)


# KEY TAKE AWAY BEIM CACHE CLEANING:
# Speichern wir Variablen in eine Liste handelt es sich um eine Referenz auf die Storage Slot und nicht um die Storage selbst.
# ERFO: Löschen wir die zugehörige Speicherung zur Storage Id welche in der Liste refrenziert wird ...
        # => wird hierdurch nicht automatisch auch die Referenz in der liste gelöscht:
         # ERGO: => Um Cache vollständig im Zuge der Löschung zu cleanen, müssen alle indirekten Referenzen zu Storage auch gelöscht werden
            