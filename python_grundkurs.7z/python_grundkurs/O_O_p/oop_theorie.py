'''####Interne Bereich
class Tier:
    def schlafen(self):
        print("zzz")
        class Hund(Tier):
            pass
        class katze(Tiere)
            pass
-----------------
#####Externer Bereich
h1=Hund()
k1=katze()
h2=Hund()
k2=Katze()

h1.schlafen()
h2.schlafen()
k1.schlafen()
k2.schlafen()
'''
