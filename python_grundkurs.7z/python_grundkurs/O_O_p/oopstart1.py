# oop
#########################################################
# Interner Bereich: Wie eigenes Modul schreiben
#########################################################

class Bankaccount:                      # Klasse deklarieren

    # KONSTRUKTOR   ==>> wird immer am Anfang aufgerufen wenn wir die Klassen aufrufen 
    def __init__(self, iban, owner):    # __init__ ist festes und erfordferliches keyword für den Funktionsnamen des Konstruktors
        self.iban = iban                # Attribut => Bei Erstaufruf je Objekt, übergeben wir IBAN
        self.owner = owner              # Attribut => Bei Erstaufruf je Objekt, übergeben wir IBAN
        self.balance = 0 
        self.frozen = False               # Paramater muss nicht in Funktion Header, weil Kontostand immer bei 0 starten soll (Kein Übergeben bei Aufruf)

    # HINWEIS: self muss in Konstruktor und in jeder Methode als erster Parameter stehen
    # HINWEIS: self. muss bei Initialisierung und bei internem Aufruf jedes Attributes vor Attribut stehen


    # METHODEN:

    # Auf Konto Einzahlen
    def deposit(self, amount):          # amount muss nicht initiiert werden, weil diese nur Transaktion gilt und daher keine Eigenschaft darstellt
        self.balance += amount

    # Von Konto A auf Konto B Transferieren
    def transfer(self, amount, to):
        if not self.frozen :
           self.balance -= amount
           to.balance += amount
           print(self.owner, "transfers", amount, "to", to.owner)

    # Von Konto Abheben
    def withdraw(self, amount):
        self.balance -= amount

    def freeze(self):
        self.frozen =True
    def unfreeze(self):
        self.frozen =False

## Neues Objekt erstellen und in einem Container (Cache) speichern

account1 = Bankaccount("123-456", "Alice Adriana")      # Erstellen eines Objektes (Erste Instanz der Klasse)
account2 = Bankaccount("654-321", "Bob Builder")        # Erstellen eines Objektes (Zweite Instanz der Klasse)
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# Verwenden der Methoden auf unseren Objekten (Instanzen)

account1.deposit(500)                   # Jemand zahlt Geld auf Konto von Alice ein
account1.transfer(200, account2)  
account1.freeze()         # Alice tranferiert Geld an Bob
account2.withdraw(50)   
                        # Bob holt Geld von seinem Konto ab
account1.freeze()
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# Ausgabe der Endkontostände zur Überprüfung unseres Codes

print(account1.owner, account1.balance)
print(account2.owner, account2.balance)


