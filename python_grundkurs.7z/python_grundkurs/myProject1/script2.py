'''if 1 == 1:
    #print(True)
    print(1 == 1)
    if 1==2:
        print(True)
    else:
        print(False)
else:
    print("the If Conditions was not found Tru'e",false)   
    '''
if myvar1 +2 == 3:
    #print(True)
     print(1 == 1)
     if 1==2 :
        print(True)
     else:
        print(False)
    else:
     print("the If Conditions was not found True",false)   
    elif myvar1 +2 == 4:
        print("The If Conditions was not fund True",False)
    elif myvar + 2 == 3:
         try:
             myvar1=myvar1 + "Some Text"
             print("yes myvar1 +2 equal 3")
         except Exception as e:
             print("An Error has occured")
     else :
print("none of the previous conditions were fullfilled")
             