myList=[0 for i in range(1,3)]
print(myList)
var = 1
while var < 10:
    print("#")
    var = var << 1
print("\n")
for i in range (1):
    print("#")
else:
    print("#")

t = [[3 - i for i in range(3)] for j in range(3)]
s = 0
for i in range(3):
    s += t[i][i]
print(s)
#---------------------------------------------
myList=[1,2,3]
for v in range(len(myList)):
    myList.insert(1,myList[v])
print(myList)

#---------------------------------
vals =[0,1,2]
vals.insert(0,1)
del vals[1]#
#
nums=[1,2,3]
vals=nums
del vals[1:2]
print(vals,nums)


'''
myList=[[0,1,2,3]for i in range (2)]
print(myList[2][0])
'''
nums=[1,2,3]
val=nums[-1:-2]
print(val)
val=nums[-3:-1:1]
print(val)

