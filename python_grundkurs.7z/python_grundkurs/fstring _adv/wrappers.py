# Wozu dienen Wrappers zB?

    # Zentralisiert . . . 
        # Loggen
        # Errors Handlen
        # Performanz testen
        # Cachen
        # sonstige Tests / Steuerungen etc


# Ziel von Wrapper => Funktionen ummanteln
# => Um dynamisch Prozesse vorher und nachher ausführen zu können

def myDecorator(func): # Decorator dient als Vermittler zwischen eigentlicher Funktion und dem Wrapper
    def wrapper():
        print("Vor myFunction")
        func()
        print("Nach myFunction")
    return wrapper

# Um den Wrapper abzurufen müssen wir den Decorator  ...
# =>> mit dem @ vor der jeweiligen Funktion (die wir zB testen wollen) abrufen
@myDecorator  
def myFunction(): # Das ist die Funktion die wir zB testen wollen
    print("Hallo") # Prozess den wir zB testen wollen

myFunction()

 
print("- " * 30)


# BEISPIEL: Kleiner Performanztest

import time 

def decoPerformance(func):
    def wrapper():
        startMS = int(time.time() * 1000)
        func()
        endMS = int(time.time() * 1000)
        duration = endMS - startMS
        print(f"Function: '{func.__name__}' duration: {duration} ms")
    return wrapper

@decoPerformance
def myFunction1():
    myList = [x for x in range(1, 10_001)]

@decoPerformance
def myFunction2():
    myList = [x for x in range(1, 1_000_001)]

myFunction1()
myFunction2()


print("- " * 30)


# BEISPIEL: Wiederverwendbarer Performanztest mit *args und **kwargs

# Dynamische Handhabung von Funktionen mit Parametern und Returns
# Für dieses Beispiel würde auch die Weiterreichung eines Parameters (für count) genügen
# Wir verwenden hier aber trotzden *args und **kwargs WEIL:
    # => der Funktionwrapper als Performanztest auf Funktionen jeglicher Art anwendbar sein soll (egal wie viele Parameter und ob mit / ohne return)

def decoPerformance2(func):
    def wrapper(*args, **kwargs): # dynamische Umsetzung via *args und **kwargs
        startMS = int(time.time() * 1000)
        result = func(*args, **kwargs)  # dynamische Abbilung des Funktionsaufrufes
        endMS = int(time.time() * 1000)
        duration = endMS - startMS
        print(f"Function: '{func.__name__}' duration: {duration} ms")
        return result, duration # result aus Original als index 0 des tuples und duraion als index 1 des tuples
    return wrapper

@decoPerformance2
def myFunction3(count): 
    myList = [x for x in range(1, count)]
    return myList

result1 = myFunction3(10_001)
result2 = myFunction3(100_001)
result3 = myFunction3(10_000_001)

# TESTAUSGABE:
# Länge der Results checken
# Datentypen der Results checken (hier tuple weil Ausgabe von 2 werten in wrapper return)
# Index 1 des Tuples ausgeben => duration
print("r1: ", len(result1), type(result1), len(result1[0]), result1[1])
print("r2: ", len(result2), type(result2), len(result2[0]), result2[1])
print("r3: ", len(result3), type(result3), len(result3[0]), result3[1])




print("- " * 30)




# BEISPIEL: Zentralisiertes Error Handling:

def decoErrorHandler(func):
    def wrapper(*args, **kwargs): # dynamische Umsetzung via *args und **kwargs
        try:
            result = func(*args, **kwargs)  # dynamische Abbilung des Funktionsaufrufes
            return result
        except Exception as e:
            print(f"!ERROR => '{func.__name__}' => {e}")
            return None     # Hier None als Indikator dafür dass ein Error stattgefunden hat: 
                            # => In Produktivumgebungen sind auch eigen Error Code Mappings denkbar und praktikabel
    return wrapper


@decoErrorHandler
def divide(a, b):
    return a / b

result = divide(10, 2)
print(result)
result = divide(10, 0)
if not result:
    pass # ggf. weiterer Code zur Verarbeitung bei Error in der Function (zB Retry, oder ErrorMessage an User, oder Fallbacklogik)
print(result)




# HINWEIS:

# In Produktivumgebungen mit Nutzern und OOP, bietet es sich an spezielle Libraries für das Wrapping zu verwenden, zB
    # import functools
    # import traceback
    
# Vorteil: Jede Funktion wird bei jedem Aufruf automatisch durch den Wrapper ersetzt ...
    # => weshalb auch keine eigene Wrapper Klasse notwendig ist => Skalierbarkeit + Performanz
