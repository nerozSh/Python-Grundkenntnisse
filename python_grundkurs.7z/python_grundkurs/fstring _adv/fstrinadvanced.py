pi=3.14659
rounded=f"{pi:.2f}"
#Mit den DDoppelpunkt bedinung
#
print("rounded",rounded)
print("-"*30)
name="Max"
print(f"(name:>10)")
print(f"(name:<10)")
print(f"(name:^10)")

rate=0.75
print(f"{rate:.0%}")

#. mit punkt steuern wir die zahl der Dezimalstellen an hier keine =0

age=30
print(f"{age=}")

from datetime import datetime
now=datetime.now()
print(f"{now:%Y-%m-%d}")
print(f"{now:%H:%M:%S}")

for i in range (1,4):
   print(f"{i} is {i**2:>100}")#wir können innerhalb F-String auch berchnungen vornehmen
myList=[1,2,3,4]
print(f"{len(myList)}")

def myFunction ():
   pass
print(f"Functionsname => {myFunction.__name__}") #Funktionsnammen ausgeben

