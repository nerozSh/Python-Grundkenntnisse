# Dictionaries sind Sequenzen aus Schlüssel-Werte-Paaren (Key-Value-Pairs)

# Dictionaries sind Mutable

# Es gibt keine Indizies, stattdessen können wir selbst 
# Namen für Schlüssel vergeben, mit denen wir auf Werte zugreifen können 

# Dictionaries waren bis Python 3.6 hashbasiert (unsortiert)
# Seit Python 3.7 sind diese aber auch sortiert

# Kann man auch als Mapping bezeichnen

# Eignen sich wenn man wirklich EINDEUTIGE Bezeichnungen für Schlüssel nutzen will
# Schlüssel müssen daher auch eindeutig sein

# Eignen sich deshalb z.B. auch für Identifikationsmöglichkeiten wie IDs
    # z.B. um über Artikelnummern auf Artikelmerkmale zuzugreifen
    # z.B. Über Kundennummern auf Kundendaten zuzugreifen

# Auch geeignet bei größeren Datenmengen, damit man nicht iterieren muss
# Man kann Datensätze bzw. Werte direkt über den Schlüssel abrufen

myDict={
        "firstname":"Max",
        "lastname":"Musterfrau",
        "age":29,
        "country":"DE",
        "city":"Berlin",
        "zip":12345,
        "hobbies":["jojjing","traddind","chess"]
        }
print("myDict",myDict)
print("\n")
_1stname=myDict["firstname"]
lastName=myDict["lastname"]
print(_1stname,lastName)
myDict["city"]= "Colonge"
print("myDict",myDict)
myDict["city"]=""
myDict["age"]=0
myDict["age"]=None
del myDict["city"]
print("myDict",myDict)
myDict.pop("zip")
print("myDict",myDict)
myDict.popitem()
print("myDict",myDict)
for key in myDict:
    print(key)

keyOfDict = myDict.keys()
print(keyOfDict,type(keyOfDict))   

# Alternativ:
country = myDict.get("country")        # Gibt Wert zurück oder None, falls Key nicht existiert
print("country", country)


# Wie ändert man z.B. einen Wert in einem Dictionary? Über den Schlüssel
myDict["city"] = "Cologne"
print("myDict", myDict)

# Wie entfernt man einen Wert wenn man der Schlüssel wegen der Datenstruktur behalten möchte?
myDict["city"] = "" # Mit Beibehaltung des Datentyps, z.B. wenn User schonmal Eingabe gemacht hatte
myDict["age"] = 0   # Mit Beibehaltung des Datentyps, z.B. wenn User schonmal Eingabe gemacht hatte
myDict["age"] = None    # Ohne Beibehaltung des Datentyps, z.B. wenn User noch nie Eingabe gemacht hatte

# Wie löscht man einen Schlüssel inkl. dazugehörigem Wert?: Über den Schlüssel
del myDict["city"]
print("myDict", myDict)
# print(myDict["city"]) # Da key zu city hier gelöscht wurde, würden wir einen KeyError bekommen beim Versuch auf den Key zuzugreifen

# Alternativ: Über den Schlüssel
'''myDict.pop("zip")
print("myDict", myDict)
'''
# Wie löschen wir das letzte Schlüsselwertepaar im Dict?
myDict.popitem()
print("myDict", myDict)

# Wie iteriert man über die Schlüssel eines Dicts:
for key in myDict:
    print(key)

# Wie erstelle ich eine Liste aus den Keys: Datentyp 'dict_keys'?
keysOfDict = myDict.keys()
print(keysOfDict, type(keysOfDict))
# Wie erstelle ich eine Liste aus den Keys: Datentyp list: zB via Casting?
myActualListOfKeys = list(myDict.keys())
print(myActualListOfKeys, type(myActualListOfKeys))
# Alternativ

keyList = [str(keys) for keys in myDict]
print(keyList, type(keyList))
print(keyList[0])

# Wie bekommt man beim Iterieren über den Key den dazugehörigen Wert?
for key in myDict:
    print(myDict[key])

# Wie kommt man beim iterieren komfortabel sohl an Key als auch an Wert
for key, value in myDict.items():
    print(key, value)

# Mann kann sich auch die vollständigen items einzeln als Tuple ausgeben:
for item in myDict.items():
    print(item)


# Prüfen zu welchen Keys im Dict der Wert None zugeweisen ist:
for key in myDict:
    if myDict[key] == None:
        print(key)


# Wie prüft man ob eine Person in Berlin lebt?
berlin = []
for key, value in myDict.items():
    if value == "Berlin":
        print(myDict["firstname"], myDict["lastname"])
        berlin.append((myDict["firstname"], myDict["lastname"]))
if not berlin:
    print("Noone lives in Berlin")



# Wie leert man ein dict?
myDict.clear()
print(myDict)


# Iterative Verdichtung: Erst prüfen ob überhaupt irgendetwas vorhanden ist
# Danach prüfen was genau vorhanden ist
if not myDict:
    print("The dictionary is empty or there is no dictionary")

    if myDict == {}:
        print("There is a dict but it is empty")
    else:
        print("There is no dictionary")

else:
    print("There is definitely no emopty and no filled dict")


# Wie löscht man ein ganzes Dict?: Cache leeren
del myDict 
try:
    print(myDict)
except Exception as e:
    print(type(e), e)



''' 
Auf Listen existiert die .items() Methode nicht => auch nicht auf Tuples oder Sets
myList = [1, 2, 3, 4, 5]
for item in myList.items():
    print(item)
'''


