#7 Vergleiche innerhalb der print Funktion zwei unterschiedliche zahlen mit dem richtigen Vergleichsoperator.
print(10>3)
print(16<6)
numberBool=True
numberBool=10
print(numberBool)
numberBool=False
print(numberBool)
