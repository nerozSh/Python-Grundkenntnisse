'''Aufgabe 1 – Dictionaries und Strings

user = {
    "id": 42,
    "name": "Alice",
    "email": None,
    "active": True,
    "score": 0
}


'''
user = {
    "id": 42,
    "name": "Alice",
    "email": None,
    "active": True,
    "score": 0
}

#a) Finde alle Keys, deren Werte Falsy sind und packe sie programmatisch in eine Liste namens falsyVals
falsyVals = []
for key, val in user.items():
    if not val:  # Prüft, ob der Wert falsy ist
        falsyVals.append(key)
print(falsyVals)

# oder 2: Using list comprehension
falsyVals = [key for key, val in user.items() if not val]
print(falsyVals)
#b) Setze alle falsy Values im Dict programmatisch auf "unknown"
for key in user:
    val = user[key]
    if not val:  # Wenn der Wert falsy ist
        val = "unknown"
 #c) Gib das angepasste Dictionary aus   
print(user)
#d) Verwandele alle Werte mit "unknown" im Dict programmatisch in Großschreibung: "UNKNOWN" ohne explizit "UNKNOWN" zu schreibe
for key in user :
   value = user[key]
   if value=="unknown":
      user[key] = value.upper()
   print(user)

#Aufgabe 2 – Reverse Mapping

colors = {
    "raspberry": "red",
    "banana": "yellow",
    "kiwi": "green",
    "sky": "blue",
    "lemon": "yellow"
}
#a) Erstelle programmatisch ein neues Dictionary, in dem Farben die Keys sind und Früchte die Values
reverseDict={}
for Früchte,Farben in colors.items():
   reverseDict[Farben]=Früchte
print(reverseDict)
#b) Was passiert, wenn mehrere Keys denselben Wert haben? (Teste durch Duplikate) #key ist  unique in dict
#Ist ein Key vorhanden und wir steuern den key an und geben den letzten Wert
reverse1={}
for Früchte,Farben in colors.items():
   if Farben in reverse1:
      reverse1[Farben].append(Früchte)
   else:
      reverse1[Farben]=[Früchte]
print(reverse1)


#Aufgabe 3 – Listen + Dicts verschachtelt

#a) Gebe den Namen jedes Users programmatisch in der Konsole aus
users = [
    {"id": 1, "name": "Tom", "city": "Berlin"},
    {"id": 2, "name": "Sara", "city": "Hamburg"},
    {"id": 3, "name": "Alex", "city": "Berlin"},
    {"id": 4, "name": "Nina", "city": "Munich"},
]
for i in users:
   print(i["name"])

users2 =[
    {"id": 1, "name": "Tom", "city": "Berlin"},
    {"id": 2, "name": "Sara", "city": "Hamburg"},
    {"id": 3, "name": "Alex", "city": "Berlin"},
    {"id": 4, "name": "Nina", "city": "Munich"},
    None,
    1,
    [],
    True,
    5,8
]
#b) Entferne programmatisch alle User die in Munich wohnen.
users = [
    {"id": 1, "name": "Tom", "city": "Berlin"},
    {"id": 2, "name": "Sara", "city": "Hamburg"},
    {"id": 3, "name": "Alex", "city": "Berlin"},
    {"id": 4, "name": "Nina", "city": "Munich"},
]
nonMunichUsers=[]
for u in users:
   if u["city"]!="Munich":
      nonMunichUsers.append(u)
users ==nonMunichUsers
print(user)
#oder
users=[u for u in users if u["city"]!="Munich"]
print(users)
#oder 
users = [
    {"id": 1, "name": "Tom", "city": "Berlin"},
    {"id": 2, "name": "Sara", "city": "Hamburg"},
    {"id": 3, "name": "Alex", "city": "Berlin"},
    {"id": 4, "name": "Nina", "city": "Munich"},
]
for u in users :
   if u["city"]=="Munich":
      curr=users.pop()
      print(curr)

#wenn wir nur das u löschen wird auf dict selbsr keine 


#c) Füge programmatisch allen Userdatensätzen den Key "suggest_friend" mit dem Wert None hinzu
for u in users :
   u["suggest_friend"]=None
   print(u)
#d) Füge für alle User, die in der selben Stadt wohnen, dem Key "not_far" den Wert True hinzu und bei allen anderen Usern den Wert False  

   users = [

    {"id": 1, "name": "Tom", "city": "Berlin"},
    {"id": 2, "name": "Sara", "city": "Hamburg"},
    {"id": 3, "name": "Alex", "city": "Berlin"},
    {"id": 4, "name": "Nina", "city": "Munich"},
]
   
   for i in users:
      for j in users:
         if i["id"]!=j["id"]:
            if i["city"]==j["city"]:
               i["suggest_friend"]=True
            else:
               i["suggest_friend"]=False
      print(i)


'''Aufgabe 4 - Lists and Sets

'''
userA = ["chess", "trading", "jogging", "chess", "music"]
userB = ["gaming", "jogging", "music", "travel", "music"]
#a) Gebe die Interessen von userA nur mit eindeutigen Einträgen in der Konsole aus
print(set(userA))
#b) Erstelle ein Set in denen die Interessen aller Nutzer eindeutig aufgeführt sind
allHobbies=set(userA + userB)
print(allHobbies)
#c) Erstelle eine Liste aus diesem Set und sortiere die Einträge alphabetisch
print("\n")
sortedList = list(allHobbies).sort()
print(sortedList)
#d) Erstelle eine Liste namens hobbyMatch in denen nur die gemeinsamen Interessen beider User ohne Duplikate aufgeführt sind
mutualHobbies=[]
for hobby in userA:
   if hobby in userB:
      mutualHobbies.append(hobby)
mutualHobbies=list(set(mutualHobbies))

#oder
mutualHobbies=[]
for hobby in userA:
   if hobby in userB and hobby not in mutualHobbies:
      mutualHobbies.append(hobby)
print(mutualHobbies)
#oder
mutualHobbies=list(set(userA)&set(userB))   #
print(mutualHobbies)

try:
   mutualHobbies=userA & userB      #
except Exception as e:
   print(e)
#
myDict1={"a":1,"b":2}               #type error
myDict2={"a":1,"c":3}
try:
     mutualKeys= myDict1 & myDict2
except Exception as e:
     print(e)


#oder

mutualHobbies=set(userA).intersection(userB)
print(mutualHobbies)
#e) Entferne das Hobby "jogging" aus der hobbyMatch Liste
mutualHobbies.remove("jogging")
print(mutualHobbies)
#f) Füge der hobbyMatch Liste den Eintrag "cats" hinzu
hobbyMatch=mutualHobbies.add("cats")
print(hobbyMatch)
#Im Falle von Sets
mutualHobbies=set(mutualHobbies)
mutualHobbies.add("cats")
print(mutualHobbies)

'''
##5Aufgabe 5 - Lists, Sets and Loops

 
'''
cats = ["🐱", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾"]

#a) Konkateniere die Katzen rückwärtiger Reihenfolge zu einer String
#catString= ''.join(reversed(cats))  #funktion
#print(catString)
catString ="   ".join(cats[::-1])
print(catString)
#cats.reverse()
#catString =''.join(cats)
#print(cats)
print(type(cats))
#oder
catString=''.join(reversed(cats))
print(catString)
#oder
catString ="   ".join(cats[::-1])
print(catString)
 
catString=' '.join(cats)
print(catString)
#b) Erstelle eine Endlosschleife
while True:
   shufledSets =''.join(list(set(cats)))  ###
   print(shufledSets)
   break
#c) In jeder Iteration sollen für die Anzahl der Einträge in der der obigen Liste zufällig Katzenemojis konkateniert werden
shufledSets=''.join(list(set(cats)))
print(shufledSets)
#oder 
shufledSets=list(set(cats))
catString=""
for cat in shufledSets:
   catString += cat
   print(catString)

   #oder 
   import random 
   random_cats=[random.choice(cats)for _  in range(len(cats))]
   cat_line="".join(random_cats) 
   print(cat_line)
#oder
   random_cats=[ random.choice(cats)for _ in range ( random.randint(1,len(cats)))]
   cat_line=''.join(list(set(random_cats)))
   print(cat_line)
   #oder
   #while True:
       #print("".join)(random.choices(cats,k=len(cats)))
   #
   #
   #

