firsName=str(input("Enter the firstname:"))
lastName=str(input("Enter the lastname:"))
print(firsName +" "+ lastName)
# 5-a Verbinde einen Text und eine Zahl zu einem Text und gebe das Ergebnis in der Konsole aus.
Age=32
Language="Python"
print(" the age value & language r:"+" "+ str(Age)+" " + Language)
# 5-b Gebe Dir den Datentyp für den Text und die Zahl separat in der Konsole aus.
print(type(Age))
print(type(Language))
# 6-a&b Simuliere einen Fehler (z.B. Division durch 0) und fange ihn mit try/except ab, um eine Fehlermeldung zu verhindern.
try:
  print(10/0) 
except Exception as e:
  print("An exception occurred",e)
  


