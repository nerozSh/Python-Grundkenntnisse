'''
Aufgabe 1 Casting

x = "4.8"
y = True

a) Warum funktioniert int(x) nicht direkt?
b) Wie kannst du trotzdem einen int-Wert aus x erhalten?
c) Was ist das Ergebnis von float(y) und warum?

'''
#1_a
x="4.8"
y=True
print(x,type(x))
#print(int(x)) # 

#1_b
x=float("4.8")
print(x,type(x))

yy=int(x)
print(yy,type(yy))
#1_c
print(float(y)) #1.0 
'''
Aufgabe 2 – Casting

data = 123

a) Was ergibt list(data) und warum?
b) Wie bekommst du aus data eine Liste mit nur einem Integer 123 als Element?
c) Wie bekommst du aus data folgende Liste aus ints: [1, 2, 3]?

'''
#2_a
data = 123
#list_num = list(data)
#print(list_num) #Error
#2_b 
List_fromNum = str(data)
print(List_fromNum)
#3_c
print(list(List_fromNum))
#[data]
lst=[]
for i in range(len(List_fromNum)):
  lst.append(int(List_fromNum))
  print(lst,i)
  #oder
  #a,b,c =list(str(data))
  #intA=int(a) 
  #intB=int(b)
  #oder
  lst1=[int(item) for item in str(data)]
  print(list)
'''
Aufgabe 3 – Casting

values = [None, "False", "", 0, [], 'None', {}, False]

a) Welche dieser Werte ergeben False, wenn du sie mit bool() castest?
b) Iteriere über die Liste und gebe in jeder Iteration den jeweiligen wert und Datentyp des Wertes aus
c) Was passiert bei int(True) und int(False)?

'''
#3_a
values = [None, "False", "", 0, [], 'None', {}, False]
a =bool(None)#false
b=bool("False")#true
c=bool("")#false
d=bool(0)#false
e=bool([])#false
f=bool('none')#true
g=bool({})#false
i=bool(False)#false
v=bool(values)#true
print(a,b,c,d,e,f,g,i,v)
#3_b
for wert in values:
   print (type(wert))
#3_c
print(int(True))#1
print(int(False))#0
'''
Aufgabe 4  Casting
val = None

a) Was passiert bei str(val) und warum?
b) Was bei int(val) und warum?
c) Warum ist bool(val) False?

'''
val = None
#4_a
print(type(str(val))) # 'None'
try:
  print(int(val)) #TypeError
except Exception as e:
  print("the exception not occured",e)
print(bool(val)) # false weil none bedeutet kein Wert und python intepriert es als false
'''myList =[1,2,3]
revList=[4]+myList[::-1]+[0]
print(myList)'''

'''
Aufgabe 5 - Tuples
val = (5)
a) Füge ein zeichen hinzu, um aus dem int ein Tuple zu machen
b) Erstelle ein Tuple in dem Du einer Variablen innerhalb von zwei Zeichen einen Wert zuweist. ??????????????????
'''
val = (5)
#5_a
val = (5,)
val=5,
valTuple = (1,2)
a,b = valTuple
print(a,b,valTuple)

'''Aufgabe 6: Tuples

data = ("Python", 2025, True)

a) Entpacke das Tuple und gebe die entpackten Werte in der Konsole aus.
b) Gebe die Anzahl der Werte im Tuple mit der richtige Python-native Funktion in der Konsole aus.
c) Erstelle programmatisch eine Liste aus dem Tuple mit Werten in umgekehrter Reihenfolge
d) Nenne drei Methoden, die auf Listen ber nicht auf Tuples existieren:
e) Finde programmatisch heraus ob der Wert True im Tuple existiert.
f) Wenn der Wert True im Tuple existiert, dann finde programmatisch den Index davon heraus'''

#6_a
data = ("Python", 2025, True)
programmiererSprache ,jahr,check = data
print(programmiererSprache,jahr,check)
#6_b
print( len(data))
#6_c
''''
newTuple = (1,2,3,1,1,5)
listOfTuple = list(newTuple)[::-1]
print(listOfTuple)
'''
#6_d
'''
append()
pop()
insert()
reverse()
clear()
remove()
'''
#6_e

for i in data:
  if type(i)== True:
    print(i,data.index(i))
    break
  else :("not exestiert")
'''
Aufgabe 7: Bonus

data = ["1", "zwei", "3", "vier", "5", 6.0, True, [1]]

a) Iteriere durch die Liste.
b) Versuche, jeden Wert als int zu casten (try/except)
c) Sammle nur die gültigen Zahlen in einer neuen Liste.
d) Sammele die Datentypen aller items von data in einer weiteren neuen Liste.
d) Caste beide neuen Listen je als ein Tuple und gebe beide Tuple in der Konsole aus
'''
data = ["1", "zwei", "3", "vier", "5", 6.0, True, [1]]
#7_a_b
for i in data :
  try:
   castWerte = int(i)
   print(castWerte)
  except Exception as e :
    print("An exception occured",e)
'''
1
An exception occured invalid literal for int() with base 10: 'zwei'
3
An exception occured invalid literal for int() with base 10: 'vier'
5
6
1
An exception occured int() argument must be a string, a bytes-like object or a real number, not 'list'
'''
listD=[]
for i in data :
    if type(i)==int or float:
     print (i)
     listD=i
    print(listD)
print(tuple(data))
print(tuple(listD))











