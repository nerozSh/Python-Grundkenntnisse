'''
aufgabe 1  Arithmetische Operatoren

a) Erstelle zwei Variablen mit Zahlen deiner Wahl und berechne:
- ihre Summe
- ihren Unterschied
- ihr Produkt
- ihr Ergebnis bei Division
- Gebe alle Ergebnissen der Konsole (Terminal) aus

b) Berechne:
- den Rest einer Division mit dem Modulo operator
- das Ergebnis einer Ganzzahldivision mit dem Floor Division Operator
- die wurzel 3 hoch 4 mit **aus-   36 mit ** (Hinweis: 0.5 als Exponent)
'''
num1 = 7
num2 = 3
numSumme = num1 + num2
numUnterschied =num1 -num2
numProdukt =num1 * num2
print("the Summe and the Unterscheid and the Produkt :","\n",numSumme,"\n",numUnterschied,"\n",numProdukt,"\n")
numDivision =num1 / num2
print("the Division:",numDivision,"\n")
numFloorDivision = num1 // num2
print("the FloorDivision:",numFloorDivision,"\n")
numExponent = 3 ** 4
print("the exponent :",numExponent,"\n")
numWurzel =36 ** 0.5
print("the wurzel num 36:",numWurzel,"\n")

'''
Aufgabe 2 – Zuweisungsoperatoren

a) Erstelle eine Variable a = 10
b) Addiere 5 auf a mit +=
c) Multipliziere a mit 2 mit *=
d) Reduziere a mit -= um 4
e) Dividiere a durch 2 mit /= und gib a nach jedem Schritt aus

'''
a = 10
print("My variable:",a)
a += 5
print("The addition:",a)
a *= 2
print("The Multiplicaition:",a)
a -= 4
print("the Substraction:",a)
a /= 2
print("the Dividision:",a)
print("\n")

'''Aufgabe 3 – Vergleichsoperatoren und Logikoperatoren

#a) Gib jeweils True oder False aus bei folgenden Prüfungen:
5 != 5
8 >= 7
2 <= 2

b) Kombiniere die diese Werte mit dem 'and' Operator und füge ein Kommentar mit dem zu erwartebnden Ergbnis hinzu. 
Danach gebe die Ergbnisse in der Konsole aus

c) Kombiniere die diese Werte mit dem 'or' Operator und füge ein Kommentar mit dem zu erwartebnden Ergbnis hinzu. 
Danach gebe die Ergbnisse in der Konsole aus


'''
vergleichNummern1 = (5 != 5)
print (vergleichNummern1)
vergleichNummern2 = (8 >= 7)
print(vergleichNummern2)
vergleichNummern3 =(2 <= 2)
print(vergleichNummern3)
print("\n")
print(vergleichNummern1 and vergleichNummern2 and vergleichNummern3) #false
print(vergleichNummern1 or vergleichNummern2 or vergleichNummern3) #true
print("\n")
'''Aufgabe 4  Listen und Loops

a) Erstelle eine Liste namens 'numList' aus Zahlen 1 bis 6
b) Erstelle eine weitere Liste und füge in diese Liste versch. Datentypen: Int, String, Float, Bool, und die erstellte numList
c) Erstelle einen Loop um die Werte aus der Liste iterativ in der Konsole auszugeben
d) Neste innerhalb des Loops ein if Statement und prüfe darin in welcher Iteration der Datentyp 'list' auftaucht (wegen der numList)
e) Wenn dieses die Bedingung in diesem If True ergibt, dann neste in dem if Block einen weiteren Loop, um die einzelnen Werte der numList auch iterativ in der Konsole auszugeben
'''
numList = [1,2,3,4,5,6]
versch_DataenList = [5,"Hallo",0.5,True,numList]
print(versch_DataenList)
print("\n")
print("my list:")
for i in versch_DataenList:
    print(i)
    print("\n")
print("My list with index:")
calc = 0
for i in versch_DataenList:
    print(calc,":" , i)
    calc += 1
print("\n")
#loop with if ::::::
for i in versch_DataenList:
    if type(i) == list:
      print(type(i),i)
      listIndex=versch_DataenList.index(i)
      print(listIndex)
      for ii in i:
        print(ii)
print ("\n")
'''
Aufgabe 5  Loops
a) Erstelle einen While Loop mit der Bedingung True, un beende die Iteration Fußgesteuert bei der 20ten Iteration
b) Erstelle innerhalb von einer Code Zeile eine Liste aus Zahlen von 1 bis 100.000 ohne eckige Klammern zu verwenden (Tipp: Nutze list() und range())
c) Gebe bdie Länge der Liste in der Konsole aus

'''

i=1
while True:
   i +=1
   if i >=20:
    break
   print(i)
print ("\n") 
rangeList=list(range(1,100_001))
print(len(rangeList))
#print(rangeList)
print("\n")   


   

    