'''Aufgabe 2:
Lass den Benutzer eine Zahl eingeben, verdopple sie und gib das Ergebnis im Terminal (Konsole) aus.
Aufgabe 3:
Hinweise:
Größer-Prüfung mit >
Kleiner-Prüfung mit <
Größer-Gleich Prüfung mit >=
Kleiner-Gleich Prüfung mit <=
Erstelle eine Variable und weise ihr den Wert 3 zu:
'''
var1 = 1
var2 = 2
print(var1)
print(var2)
var3=   int(input("Enter a number :"))
var4 = var3 * 2
print("the double number:", var4)
if(var3 >=5):
  print(True)
elif ( var3 < 3 ):
   print(False)
elif (var3 == 3):
   print(3)
else :
   print(False)
var6 = int(input("Another Number"))







