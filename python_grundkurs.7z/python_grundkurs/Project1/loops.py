myList =["H","a","l","l","o"]
print(len(myList),"\n")
for char in myList:
    print(char)
print("\n")

'''concat =""
for char in myList:
    concat+=char
    print(concat)
print("\n")
print(concat,"\n")
print("".join(myList))
print("\n")
myList=[1,2,3,4]
calc=0
for num in myList:
   calc=calc+num
   print(calc)
print("\n")
print(calc,"\n")

calc=0
for i in range(5):#itiert von 1 bis 4 =>die angegeben Zahl ist als exclusive
  print (i)
  calc +=i
  print(calc,"\n")  
for i in range (5):
     calc +=i
     print(calc,"\n")  
for i in range (3,5):
     calc +=i
     print(calc)
     print(calc,"\n")

for i in range (-10,8,4):
     calc +=i
     print(calc)
     print(calc,"\n")
while True:#keine stop
   calc +=1
   print(calc)
while 1 == 1 :
   calc += 1
   print(calc,"\n")
calc = 0
while calc < 10:
        calc += 1
        print(calc)
        if calc == 10:
           break
print("calc","\n")
#quicklist=

import os 
calc=0
while True:
   calc +=1
   if calc % 10_000_000 ==1:
      os.system('cls'if os.name =='nt' else 'clear')
      print()
'''
