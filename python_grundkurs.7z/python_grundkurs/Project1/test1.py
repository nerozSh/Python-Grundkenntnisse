farben=["rot","grün","blaugelb"]
calc=1
for i in farben:
    print(calc," ",i)
    calc +=1
print("\n")
i = 1
while True:
    if i<=10:
        print(i)
        i+=1
print("\n")   
import os   
counter1 = 1
while True:
    counter +=1 
    os.system ('cls' if os.name == 'nt' else clear )
    print("num is",counter1)
    if couter1 < 5:
               break
    print(counter1)
    


       