### PERMANENTER SPEICHER (z.B. FESTPLATTE / CLOUD)

import json

# Was ist json?
    # .json ist ein Dateiformat
    # json steht für "Javascript Object Notation" => was nicht hiesst dass wir dafür Javascript benötogen
    # für strukturierte Daten (Datenhierarchie) auf Dictionary-Basis
    # Standard bei No-SQL Datenbanken (nicht relationale Datenbanken), zB Google Firestore (Firebase)
        # => auch dokumentenbasierte Datenbank genannt 
    # Häufig bei APIs (Application Program Interface) => Schnittstellen um z.B. mit Servern zu kommunizieren
    # z.B. mit externen Libraries (oft paid Plan) wie z.B. OpenAI
    # Nutzt i.d.R. HTTP GET Requests, um Daten abzufragen (sogenanntes "Fetchen")
    # Oder für eigens-erstellte APIs via HTTP POST Request (Senden)
    # JSON ist DER Standard für objektbasierte Datenstrukturien, der in etwaigen Programmierprachen kompatibel ist (i.d.R nach Derialisierung), z.B. Java, Typescript, Python, C#, Ruby, and whatnot


userDB = {
    "001": {"firstname": "Adrian", "lastname": "Ahnsdorf", "gender": "m"},
    "002": {"firstname": "Beate", "lastname": "Bach", "gender": "f"},
    "003": {"firstname": "Christian", "lastname": "Caesar", "gender": "m"},
    "004": {"firstname": "Doro", "lastname": "Dallmann", "gender": "d"},
    "005": {"firstname": "Edeltraut", "lastname": "Ermke", "gender": "f"},
}

filename = "userDB.json"


#file = open(filename, "w")
#json.dump(userDB, file)


with open(filename, "w") as f:      # json write
    json.dump(userDB, f)

print("\n")

with open(filename, "w") as f:      # prettified json write
    json.dump(userDB, f, indent=4)

print("\n")

data = {}
with open(filename, "r") as f:      # read json
    data = json.load(f)

print("data", data)

# Aus JSON gelesene Daten manipulieren

del data["005"]
data["001"] = {"firstname": "Anna", "lastname": "Ahnsdorf", "gender": "f"}
data["006"] = {"firstname": "Frank", "lastname": "Fulda", "gender": "m"}


# Manipulierte Daten wieder in JSON schreiben 
with open("userDB.json", "w") as f:    # prettified json write für die ausgelesene json file
    json.dump(data, f, indent=4)

with open("userDB.txt", "w") as f:     # prettified txt write für die ausgelesene json file
    json.dump(data, f, indent=4)

with open("userDB.md", "w") as f:      # prettified json write für die ausgelesene json file
    json.dump(data, f, indent=4)



    
# Beispiel für verschiedenartige Speicherungen für Euer Textadventure 
'''
    "dungeonHero87": {
        "gold": 100,
        "lastlevel": 5,
        "items": ["platinumKnightSword", "ironHelmet", "zaubertrank"]
    },
    "goblinFighter2005": {
        "gold": 100,
        "lastlevel": 5,
        "items": ["platinumKnightSword", "ironHelmet", "zaubertrank"]
    },
    "allAssets": {
        "platinumKnightSword": {"damage": 50, "cost": 150},
        "lastname": "Bach",
        "gender": "f"
    },
'''