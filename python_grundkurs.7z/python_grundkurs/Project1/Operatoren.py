#Identitätoperation (prüfen zustand)
print(1 is 2)
print(1 is not 2)
print(2 is not 2)
#Inhaltsoperatoren (Membership-operation)
print("a" in "Hallo")
print("a" not in "Hallo")
#print(1 in 1)#type Erorr(nicht iterable wie String tuple dict set list)
#not(keywords konnten kein variable sein)
# Listen (in anderen Programmierersprachen of "array" gennant)
myListOfNumber = ["a","b","c","d"]
print("myListOfNumber",type(myListOfNumber),myListOfNumber)
myListOfWhatNot = [ 1,"a",True,False,None,-5,6.9,[],[1,1,"Max",True]]
print("myListOfWhatNot", myListOfWhatNot)
myListOfCat = ["💕","💕","💕",type("💕")]
myList =["a","b","c","d","e"]
_1stIndex = myList[0]
_2ndIndex = myList[1]
_lastIndex = myList[-1]
_preLastIndex=myList[-2]
print(_1stIndex,_2ndIndex,_lastIndex,_preLastIndex)
# Wert an das Ende der List anfügen
myList.append("f")
print(myList,"\n")
#Wert an anfang der Liste beifügen 
myList.insert(0,"z")
print("myList",myList,"\n")
#Alternazive Art umwert an anfang bzw. Ende list zu setzen

#Wert in Liste einsetzen aber weder am anfang noch am ende
myList.insert(3,"r")
print("myList",myList,"\n")
#Teile der listre ansteuern bzw .ausgeben 
print(myList[:])#gleiche wie m list
print(myList[0:3])#
print(myList[:3])
print(myList[2:3])#weil von Index gröSe ist als bis-Index,können keine werte angeben
print(myList[-3:])#zeigt werte ab drittleztem Wert bis letzten Wert an .Gleiche wie myList[-3:-1]
myString =' '.join(myList)# Die liste wert als String gemered .Methode .join 
print(myString,type(myString),"\n")
myList.reverse()#Liste Umdrehen
print("myList",myList,"\n")
#Liste umdrehen .Alternative
newList = myList[::-1]
print("My re-reversed List",newList,"\n")
newListSkiptIndicies = myList[::-2]
print("My Re_Reversed List with skip ",newListSkiptIndicies,"\n")
'''#joining Numlist via String Casting
merge=str(1)+str(1)
print(type(merge),merge)
print(int(merge))
myIntList=[1,2,3,4]
mergeViaJoin =str(myIntList)
mergeViaJoin =mergeViaJoin.replace(" ","")
recastStringifiedListBackTolist =list(mergeViaJoin)'''
#Prüfe ob Cats in der Liste ist :
hasCat ="💕" in myList
print("hasCat",hasCat)
catIndex = myList.index("💕")
print("catIndex",catIndex)
if hasCat:
    catIndex=myList.index("💕")
    print(myList[catIndex])
    if catIndex:
     print(myList[catIndex])
# Liste Sortieren 
myList.sort()

myList.clear()
print("myList",myList)
#del myList
#print("myList",myList)#NameError ,so als 



