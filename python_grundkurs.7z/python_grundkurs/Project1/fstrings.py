myVar =5
myFString=f"Der Wert {myVar} ist in meiner Variable gespeichert"
print("myFstring",myFString)
#wann Ist Tendentiellkonkatienieren geeignet und wann F STring
#
#
userDB = {
    1: {"firstname": "Adrian",      "lastname": "Ahnsdorf",     "gender": "m"},  
    2: {"firstname": "Beate",       "lastname": "Bach",         "gender": "f"},  
    3: {"firstname": "Christian",   "lastname": "Caesar",       "gender": "m"},  
    4: {"firstname": "Doro",        "lastname": "Dallmann",     "gender": "d"},  
    5: {"firstname": "Edeltraut",   "lastname": "Ermke",        "gender": "f"},  
}
prefixMap={
    "m":["Lieber","Herr"],
    "f":["liebe","Frau"],
    "d":["Hallo",""]
}

for key,value in userDB.items():
    isDiverse = value["gender"]=="d"
    prefixAndName=""
    if isDiverse:
        prefixAndName = f"{value["firstname"]}{value["lastname"]}"
    else:
        prefixAndName=f"{prefixMap[value["gender"]][1]} {value["lastname"]}"
        greeting = f"{prefixMap[value["gender"]][0]} {prefixAndName}"
        print(greeting)