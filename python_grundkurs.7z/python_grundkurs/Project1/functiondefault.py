# F U N C T I O N   D E F A U L T S

# WICHTIG: Parameter mit Defaults müssen immer am Ende der Parameterkette stehen !
# Sonst Error: Weil Python wüsste sonst nicht, welche Argumente welchen Parametern zuzuordnen sind

def myFunction(p1, p2, p3, p4, p5 = 5):           # Funktionsdefinition (Declacarion)
    return p1, p2, p3, p4, p5                     # Wir packen mehrere Werte als Antwort in den Return

a = 7
b = 2
c = 3
d = 4

myList = [a, b, c, d]

# Wir können mehrere Werte aus der Antwort der Funktion entpacken
# Voraussetzung (Wir packen im Return der Funktion die selbe Anzahl an Werten) 

_p1, _p2, _p3, _p4, _p5 = myFunction(myList[0], myList[1], myList[2], myList[3])                # Funktionsaufruf (Invokation)


print("result", _p1, _p2, _p3, _p4, _p5)

# RECAP: Wir können z.B. bei Tuples (und generell bei Seqquenzen auch packen und entpacken)
#myTuple = (1, 2, 3, 4)
#a, b, c, d = myTuple
print(*myFunction(a,b,c,d))