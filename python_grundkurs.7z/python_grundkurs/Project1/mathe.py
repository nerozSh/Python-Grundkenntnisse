import math                                 # Achtung: Dateiname darf nicht Name der Library sein


# Potenzen
myExpontialCalcWithoutMathLib = 2 ** 4
print("myExpontialCalcWithoutMathLib", myExpontialCalcWithoutMathLib) 

potenz = math.pow(2, 4)                     # Erstes Argument = Basi (Zahl die wir potenzieren wollen) ... Zweites Argument = Exponent (Zahl um die wir potenzieren)
print("potenz", potenz) 


# Quadratwurzel

mySquareRootWithoutMathLib = 36 ** 0.5
print("mySquareRootWithoutMathLib", mySquareRootWithoutMathLib)

mySquareRoot = math.sqrt(36)
print("mySquareRoot", mySquareRoot)


# Periodische Dezimalzahl berechnen


myLongFloat =1/0.9
print("myLongFloat",myLongFloat)
myFloor=math.floor(myLongFloat)
print("myFloor",myFloor)


myCeil=math.ceil(myLongFloat)
print("myCeil",myCeil)

# Auf zwei Kommastelle aufrunden:
myCeilFloat = math.ceil(myLongFloat * 100) / 100
print("myCeilFloat", myCeilFloat)

# Auf zwei Kommastelle abrunden:
myFloorFloat = math.floor(myLongFloat * 100) / 100
print("myCeilFloat", myFloorFloat)

 #in Math gibt es :
myTruncInt=math.trunc(myLongFloat)
print("mytruncInt",myTruncInt)
#ABER was IST BEI NEGATIVEN ZAHLEN?
myNegFloor=math.floor(-3.7)
print("myNegFloor",myNegFloor)

myNegCeil=math.ceil(-3.7)
print("myNegCeil",myNegCeil)


myNegTrunc=math.trunc(-3.7)
print("myNegTrunc",myNegTrunc)
potenz=math.pow(2,4)
print("potenz",potenz)

#myExpontialCalcwithoutMathlib