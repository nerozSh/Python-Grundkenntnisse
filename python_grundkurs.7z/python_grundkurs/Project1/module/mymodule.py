myVar =10
def myFunction(p1,p2):
    print("myFunction called")
    return p1+p2