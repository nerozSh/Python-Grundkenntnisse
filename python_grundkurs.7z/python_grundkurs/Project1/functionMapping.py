def function1(p):return p+1
def function2(p):return p+2
def function3(p):return p+3
def function4(p):return p+4
p=1
##
if p==1:
   result=function1(p)
elif p==2:
   result=function2(p)
elif p==3:
   result=function3(p)
elif p==4:
   result=function4(p)
else:
   raise Exception ("bbb")
print(result)
#Variante 
p=1
#Vermitteln(Mediator)
myFunctionHandler={
   1:function1,
   2:function2,
   3:function3,
   4:function4,
}
#
#
#
#
result = myFunctionHandler[p](p)
print("result handler",result)

#Variante B=> (Switch)
p=3
match p:
   case 1:result=function1(p)
   case 2:result=function2(p)
   case 3:result=function3(p)
   case 4:result=function4(p)
   case _:print("default")
print("result match",result),

