# F U N K T I O N E N   &   P R O Z E D U R E N

    # Dienen zur Auslagerung bzw. Zentralisierung von Prozessen
    # Prozess muss nur einmal geschrieben werden und kann von überall aufgerufen werden
            # => DRY: Don't Repeat Yourself
    # => #WIEDERVERWENDBARKEIT #MODULARITÄT #ÜBERSICHT #STRUKTUR 
    # Beim Aufruf können der Werte an die Funktion / Prozedur übergeben werden  => Argumente
    # ERGO: In der Funktion / Prozedur können Werte entgegenommen               => Parameter

# FUNKTIONEN
    # Funktionen geben auch Werte zurück => Return
    # Zurückgegebene Werte können beim Abruf auch wieder entgegengenommen werden

# PROZEDUREN
    # Werden oft mit Funktionen verwechselt, da Deklaration und Aufruf ähnlich gestaltet
    # Kernunterschied zu Funktionen:
        # Geben KEINE Werte zurück und daher können beim Abruf auch KEINE Werte entgegen genommen werden

# HINWEIS:
    # Wir werden häufig sowohl Funktionen als auch Prozeduren als Funktion bezeichnen
    # Warum? Bezeichnung "Prpzedur" ist i.d.R. eher theoretischer Natur


# SCOPE
    # GLOBALE VARIABLE:
        # Wird außerhalb von Funktionen deklariert
        # Ist sowohl von außerhalb als auch von innerhalb Funktionen/Prozeduren verfügbar bzw. aufrufbar

    # LOKALE VARIABLE:
        # Wird innerhalb von Funktionen deklariert
        # Ist nur innerhalb jener Funktion in welcher sie deklariert wird, verfügbar


# SETTER
    # => Schreiben in globale Variable 

# GETTER 
    # => Schreiben NICHT in globale Variable
    # Der dient i.d.R nur um zu lesen und um uns einen Wert zurück zu geben
    # ERGO: => Wird i.d.R als Funktion verwenden, weil wir uns den Wert den wir lesen wollen i.d.R voa Return ausgeben wollen



#
myVar =100                    #global variable von überall aufrufen
#################################################
def myProcedure():           #deklartion ohne parameter
    print("procedure")
myProcedure()                #Aufruf ohne Argumente
#Hinweis:aufruf darf erst unter Deklaration stattfinden
#=>Denn Code wird von oben nach unten interpretiert 
#----------------------------'----------------------------
def myFunction():              #declaration ohne parameter 
    myReturnVar ="MyFunction" #lokale variable nur innerhalb der funktion
    return myReturnVar         #rückgabe des Werts in den wir in die Lockale 
resultOfMyFunction =myFunction() #wir nehmen den Return wert entgegeben und dieser steht uns  nun auch global zur Verfügung über resultOfMyFunction
print(resultOfMyFunction)        #Beweiß dass wert aus rückgabe uns nun global zur Verfüging steht
print(myFunction())
print(myFunction)  #So Können wir die funktion selbst nicht aufrufen bzw ausführen sondern wir erhalten lediglich die eindeutige Positionen der funktion im Storage => Quasi ID_nummer => i.d.R ein Hash "0x..."

def myGetterFunction(p1,p2):##Deklartion mit Parameter => x
   myVar=0
   myVar=myVar+p1+p2      #Die Parameter sind als lokal variablen verfügbar => und wir schreiben sie in den flüchtigen Speicher myVar
   return myVar     ## Wir geben das Ergebnis der Berechnung wiede zurück

resultOfMyGetter=myGetterFunction(1,2) #wir überreichen 2 Argumente (hier Integers) an unsere eigene Funktion
print(resultOfMyGetter)
########################################################
def mySetterProcedure(p1,p2):
    global myVar                #mit gloabl sagen wir in python dass wir uns auf eine globale Variable
    myVar=myVar + p1 +p2         #Globale Variable kann nun von innerhalb der funktion aus manupilieren
mySetterProcedure(1,2)
########################################
def mySetterFunction():
    valueToAdd=1000
    global myVar
    myVar = valueToAdd
    return valueToAdd
addedValue=mySetterFunction()
print("we added folowing value:",addedValue)
###################################
def myGetterProcedure():
    print(myVar)
myGetterProcedure()
#p1=1 #neue Variable
##########################################################################################
def myFunctionInAnotherFunction(p1,p2):
    result=myGetterFunction(p1,p2)
result=myFunctionInAnotherFunction(5,5)
def myFunctionInAnotherFunction(p1,p2):
   result= myGetterFunction(p1,p2)
   result+=10
   return result
result=myFunctionInAnotherFunction(5,5)
##############################################
print("\n")
def myRecursive(p1):
    if p1 >= 100:
        return p1
    else:
        return myRecursive(p1 + 10)
print(myRecursive(10))


#key Takeaway
 # Man muss den selben Code nicht immer wieder schreiben
    # Sondern wir können ihn in einen Funktion packen
    # Und einfach die Funktionen aufrufen
    # Damit sparen wir uns Wiederholungen
    # und können z.B. bei Codeänderung nur einmal etwas anpassen und sind fertig (statt X mal wenn wir uns wiederholt hätten)

    # Die Funktion kann antworten => via Return => Funktion
    # Wir können in Funktion in globale Variable schreiben (via keyword 'global') => Setter
    # Benutzen wir 'global' nicht => haben wir nur lokale Variable (flüchtig und nur innerhalb der Funktion nutzbar)

    # Wir können innerhalb von Funktionen auch anderen Funktionen aufrufen
    # Eine Funktion kann sich auch selbst aufrufen => rekursiv
