#Start
gold=0
userWantsToPlay=False
while True:     #endlos schleife
        startReplay=input("Möchtest du spielen(y/n)")        
        if startReplay=="y":
            userWantsToPlay=True
            print("super,lass un spielen")
            break
        elif startReplay=="n":
            userWantsToPlay=False
            print("Schade dass du nicht spielen willst")
            break
        else:
             print("Du darfst nur y oder n eingeben,bitte versuch es erneut ")


print("userWantsToPLay",userWantsToPlay)

if userWantsToPlay:
       print("level1 gestartet.Tür geht auf .Goblin steht vor dir ")
       print("willst Du ihm eine verpassen?(1) oder willst du ihn freundlich grüSSen?(2)")
       reply=input("Treffe eine entscheidung :...")
       if reply=="1":
            print("oh Du bist aber aggressiv.Der Goblin hat ziemlich was auf dem kastet und hat divh geknocket")
            print("GAME OVER!!!!!!!!!!!!!!")
            userHasGreatGolbin=False
       elif reply == "2":
            print("oh Du bist sympatisch,er öffnet dir ein Tor und gibt sogar noch 100 goldmünzen")
            userHasGreatGolbin=True
            gold += 100
            print("Deine KontoStand:",gold)
       else:
            print("Du hast keine entscheidung getroffen")
            print("DEr Goblin fand es Strange dass Du da einfach nur standest")
            print("GAME OVER")
            userHasGreatGolbin=False


if userHasGreatGolbin:
    print("Level 2 gestartet. Du hast das Tor durchschritten und stehst vor einem Drachen!")
    print("Willst du ihn herausfordern? (1) Oder ihn lieber in Ruhe lassen? (2)")

    # Second level, facing a dragon
    reply = input("Treffe eine Entscheidung: ")

    if reply == "1":
        print("Du hast den Drachen herausgefordert!")
        print("GAME OVER!!! Der Drache hat dich verbrannt!")
        
    elif reply == "2":
        print("Du hast den Drachen in Ruhe gelassen. Er erkennt deine Weisheit und gibt dir 200 Goldmünzen.")
        gold += 200  
        print("Dein Goldstand:" ,gold)
    else:
        print("Du hast keine Entscheidung getroffen. Der Drache greift dich an!")
        print("GAME OVER!!! Du bist verbrannt!")
     
        print("Das Spiel ist zu Ende!")