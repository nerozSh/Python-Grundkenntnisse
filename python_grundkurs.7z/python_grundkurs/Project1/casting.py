#Casting
# wir konverterin hier Datentypen
#Eignet sich der jeweiligen 

#interprietieret die 1 als string(text) 
myStringNum = "1" 
myStringFloat ="1.5"
myStringText ="Hallo"

myInt =1
myFloat =1.5

myBoolTrue =True
myBoolFloat =False

myListofNum =[1,2,3]
myListofText =["a","b",'c']
myListofNumAndText =[1,"a",2,"b"]

myNone = None
'''
print("\n\n")
print("Cast to Int")
try:print(int(myStringNum))
except Exception as e: print(e)
try:print(int(myStringFloat))   #error weil dezimalzahl nicht direkt von
except Exception as e: print(e) 
try: print(int(myFloat))
except Exception as e:print(e)#ok
try: print(int(myBoolFloat))
except Exception as e:print(e)#ok=0
try: print(int(myListofNum))
except Exception as e:print(e)#ok=1
try: print(int(myListofNumAndText))
except Exception as e:print(e)#int()
'''
'''
print("\n\n")
print("Cast to float")
try:print(float(myStringNum))
except Exception as e: print(e)#1.0
try:print(float(myStringFloat))   #1.5
except Exception as e: print(e) 
try:print(float(myStringText))   #could not convert
except Exception as e: print(e) 
try: print(float(myFloat))#1.5
except Exception as e:print(e)# 1.0
try: print(float(myBoolFloat))
except Exception as e:print(e)#ok=0.0
try: print(float(myListofNum))#float()
except Exception as e:print(e)#float()
try: print(float(myListofNumAndText))#float)()
except Exception as e:print(e)#float()
'''
'''
print("\n\n")
print("Cast to text")
try:print(str(myStringNum))# 1
except Exception as e: print(e)
try:print(str(myStringFloat))   #1.5
except Exception as e: print(e) 
try:print(str(myStringText))   #"Hallo"
except Exception as e: print(e) 
try: print(str(myInt))# 1
except Exception as e:print(e)
try: print(str(myFloat))#
except Exception as e:print(e)# 1.5
try: print(str(myBoolTrue))# True
except Exception as e:print(e)
try: print(str(myBoolFloat))# False
except Exception as e:print(e)
try: print(str(myListofNum))#[1,2,3]
except Exception as e:print(e)
try: print(str(myListofText))#['a','b','c']
except Exception as e:print(e)
try: print(str(myListofNumAndText))#[1,'a',2,'b']
except Exception as e:print(e)
try: print(str(myNone))#None
except Exception as e:print(e)
'''
'''
print("\n\n")
print("Cast to text")
try:print(bool(myStringNum))# True
except Exception as e: print(e)
try:print(bool(myStringFloat))   #True
except Exception as e: print(e) 
try:print(bool(myStringText))   #True
except Exception as e: print(e) 
try: print(bool(myInt))# True
except Exception as e:print(e)
try: print(bool(myFloat))#True
except Exception as e:print(e)
try: print(bool(myBoolTrue))# True
except Exception as e:print(e)
try: print(bool(myBoolFloat))# False
except Exception as e:print(e)
try: print(bool(myListofNum))#True
except Exception as e:print(e)
try: print(bool(myListofText))#True
except Exception as e:print(e)
try: print(bool(myListofNumAndText))#True
except Exception as e:print(e)
try: print(bool(myNone))#False
except Exception as e:print(e)
try: print(bool([]))#False
except Exception as e:print(e)
try: print(bool(0))#False
except Exception as e:print(e)
try: print(bool(""))#False
except Exception as e:print(e)
myVar =""
if myVar:
    print(True)
else:
    print(False)
'''

print("\n\n")
print("Cast to list")
try:print(list(myStringNum))# ['1']
except Exception as e: print(e)
try:print(list(myStringFloat))   #['1','.','5']
except Exception as e: print(e) 
try:print(list(myStringText))   #['H', 'a', 'l', 'l', 'o']
except Exception as e: print(e) 
try: print(list(myInt))#'int' object is not iterable 
except Exception as e:print(e)
try: print(list(myFloat))#'float' object is not iterable
except Exception as e:print(e)
try: print(list(myBoolTrue))# 'bool' object is not iterable
except Exception as e:print(e)
try: print(list(myBoolFloat))#'bool' object is not iterable
except Exception as e:print(e)
try: print(list(myListofNum))#
except Exception as e:print(e)
try: print(list(myListofText))#
except Exception as e:print(e)
try: print(list(myListofNumAndText))#
except Exception as e:print(e)
try: print(list(myNone))#
except Exception as e:print(e)