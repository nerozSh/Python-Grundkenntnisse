#N U T Z E R D A T E N B A N K    S I M U L A T I O N
########################################################################


########################################################################
# D E K L A R A T I O N E N   D E R   F U N K T I O N E N
########################################################################

userDB = {
    1: {"name": "Arnold", "alter": 21, "hobbies": ["schwimmen", "gaming"]},
    2: {"name": "Burma",  "alter": 22, "hobbies": ["anime", "twitch"]},
    3: {"name": "Christian", "alter": 23, "hobbies": ["muay thai", "fußball"]},
    4: {"name": "Dorothea", "alter": 24, "hobbies": ["poker", "schach"]},
    5: {"name": "Emine", "alter": 25, "hobbies": ["triathlon", "trading"]},
    6: {"name": "Faruk", "alter": 26, "hobbies": ["coding", "gaming"]},
    7: {"name": "Gerda", "alter": 27, "hobbies": ["reiten", "turmspringen"]},
    8: {"name": "Harald", "alter": 28, "hobbies": ["malen", "kochen"]},
    9: {"name": "Ilka", "alter": 29, "hobbies": ["tanzen", "lesen"]},
}
def _readDB():              # ganze Datenbank lesen
    return userDB

def _printDBPerLine():      # Ganze Datenbank zeilenweise ausgeben
    for key, value in userDB.items():
        print(value)

def _countUsers():          # Anzahl der Nutzer lesen
    return len(userDB)

def _averageAge():          # Durchschnittsalter ermitteln
    averageAge = 0 
    for key, value in _readDB().items():
        averageAge += userDB[key]["alter"]
    averageAge /= _countUsers()
    return averageAge

def _deleteUser(userID):    # Einen Nutzer löschen
    del userDB[userID]

def _isOverAverage(userID): # Check ob User über Durchschnittsalter
    if userDB[userID]["alter"] > _averageAge():
        return True
    else:
        return False
    

########################################################################
# A U F R U F E    D E R    F U N K T I O N E N
########################################################################

def main():


    ### Delete User with ID 9 if Over Average
    if _isOverAverage(9):
        _deleteUser(9)

    print(userDB, "\n\n")



    ### Delete All Users that are Over Average
    collectIDs = []
    for key, val in userDB.items():
        if _isOverAverage(key):
            collectIDs.append(key)

    print("Overaverage Users:", collectIDs)

    for id in collectIDs:
        _deleteUser(id)
    collectIDs = []

    _printDBPerLine()


########################################################################
# A U F R U F   D E R    M A I N   F U N K T I O N