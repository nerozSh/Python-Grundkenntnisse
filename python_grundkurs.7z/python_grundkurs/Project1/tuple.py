# sind eine art von sequenzen (so wie Listen)
#Uterschied zu Listen ?


myTuple =(1,2,3)
print(myTuple)
#Alternativ via Packing:
myTuple=1,2,3
print(myTuple)
#Erstellung von Tuple via Cating from List
myList =[1,2,3,4]
myTuple =tuple(myList)
print(myTuple)
print("\n")
#Gesamtes Tuple in konsole ausgeben 

#Abruf und Ausgeben von einzelen werten im Tuple 
indexOfMyTuple=myTuple[0]
print(indexOfMyTuple)
lastIndexofMyTuple=myTuple[-1]
print(lastIndexofMyTuple)
#Unpacking von Tuples and Listen auch bei anderen Variables)
#Wichtig:
lengthOfTuple=len(myTuple)
a,b,c,d = myTuple
print(a,b,c,d)
notTuple=(1)  #Runde Klammern
print(notTuple,type(notTuple))
isTuple=(1,)#tuple Mindestin ein Komma
print(isTuple,type(isTuple))
print(len(isTuple))
minTuple=1,
print(minTuple,type(minTuple))
#Die Index



newTuple= 1,2,1,3,1,4,1
häufigkeitDerZahl1=newTuple.count(1)
print("häufigkeitDerZahl1",häufigkeitDerZahl1)
#versuche werte im Tuple selbst zu Ändern
'''try:
    newTuple[0]=2 #Immutable
except Exception as e:
      #pass
      print("some error has occured:",type(e),e)
print("\n")
#WElche Methoden exsistieren nict auf tuples?
try:
     newTuple.pop(0)
except Exception as e:
      #pass
      print("some error has occured:",type(e),e)

try:
     newTuple.append(5)
except Exception as e:
      #pass
      print("some error has occured:",type(e),e)
      '''
      
#Welche Methoden 

#Neue 
myList =list(myTuple).reverse()
print(myList)
#myList =list(myTuple)[::-1]
#print(myList)
modifiedTupleClone = myTuple[1:2]
print(type(myTuple[::-1]))
print(type(modifiedTupleClone),modifiedTupleClone)