 
myString = 'Hallo Welt'
myNum = "123"
myAlphaNum = "1st"
 
 
 
print("### Teile von Strings via Index (String = Sequenz)")
print(myString[0:5], "\n")
 
 
print("### Prüfung auf Teilstrings via 'in'")
hasHallo    = "Hallo" in myString
print(hasHallo, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung auf Teilstrings am Anfang:")
startsHallo = myString.startswith("Hallo")
print(startsHallo, "\n")
 
 
print("### Prüfung auf Teilstrings am Ende:")
endsWelt = myString.endswith("Welt")
print(endsWelt, "\n")
 
print("\n")
 
 
 
 
 
 
print("### Prüfung ob nur Buchstaben:")
 
hasOnlyLetters = myString.isalpha()
print(hasOnlyLetters, "\n")
 
hasOnlyLetters = myAlphaNum.isalpha()
print(hasOnlyLetters, "\n")
 
print("\n")
 
 
 
 
 
 
print("### Prüfung ob nur Buchstaben und Zahlen:")
 
hasAlphaNum = myAlphaNum.isalnum()
print(hasAlphaNum, "\n")
 
hasAlphaNum = myNum.isalnum()
print(hasAlphaNum, "\n")
 
hasAlphaNum = myAlphaNum.isalnum()
print(hasAlphaNum, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung ob nur Zahlen:")
 
hasOnlyNums = myAlphaNum.isdigit()
print(hasOnlyNums, "\n")
 
hasOnlyNums = myNum.isdigit()
print(hasOnlyNums, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung ob nur Spaces:")
 
mySpace = " "
hasOnlySpaces = mySpace.isspace()
print(hasOnlySpaces, "\n")
print("\n")
 
 
 
 
print("### Text in Großbuchstaben verwandeln:")
 
myString = myString.upper()  
myNum = myNum.upper()  
myAlphaNum = myAlphaNum.upper()  
print(myString)
print(myNum)
print(myAlphaNum)
print("\n")
 
 
 
 
print("### Text in Kleinbuchstaben verwandeln:")
 
myString = myString.lower()  
myNum = myNum.lower()  
myAlphaNum = myAlphaNum.lower()  
print(myString)
print(myNum)
print(myAlphaNum)
 
print("\n")
 
 
 
print("### Anfangsbuchstaben von jedem Wort groß starten:")
 
myString = myString.title()
print(myString)
print("\n")
 
 
 
 
print("### Nur erstes Wort groß starten:")
 
myString = myString.capitalize()
print(myString)
print("\n")
 
 
 
 
print("### Aüßere Leerzeichen ( White Spaces) entfernen:")
 
myString = "   " + myString + "   "
myString = myString.strip()
print("."+myString+".","\n")
print("\n")
 
 
 
 
print("### Teilstring ersetzen:")
 
myString = myString.replace("Welt", "Jupiter")
print(myString)
print("\n")
 
 
 
 
print("### Teilstring ersetzen:")
 
myString = myString + " Jupiter" + " Jupiter" + " Jupiter"
myString = myString.replace("Welt", "Jupiter", 1).strip()
print(myString)
myString = myString.replace("Welt", "Jupiter").strip()      # Default 3rd arg is all
print(myString)
print("\n")
 
 
 
 
 
myCodeAsString = '''
myString = "  (Hallo Welt)  "
myString = myString.strip()
print(myString)
print("\n")
'''
 
 
print("### Alle 'myString' durch 'ourString' ersetzen:")
myCodeAsString = myCodeAsString.replace("myString", "ourString")
print(myCodeAsString, "\n")
 
 
 
 
print("### Rückgabe des Startindex des ersten Vorkommens")
firstRoundBracket = myCodeAsString.find("(")                
print(firstRoundBracket)
 
print("### Rückgabe -1 wenn nichts gefunden")
firstRoundBracket = myCodeAsString.find("heinzelmännchen")
print(firstRoundBracket)
print("\n")
 
 
 
 
print("### Teilstring innerhalb eines Bereiches finden und ersetzen:")
print("##### Alle Strings innerhalb von () ersetzen")
start = 0
while True:
    openIndex = myCodeAsString.find("(", start)
    closeIndex = myCodeAsString.find(")", openIndex)
 
    if openIndex != -1 and closeIndex != -1 and closeIndex > openIndex:
        inside = myCodeAsString[openIndex + 1 : closeIndex].strip()
        if inside:  # nur ersetzen wenn Inhalt zwischen Klammern
            myCodeAsString = myCodeAsString[:openIndex + 1] + "'placeholder'" + myCodeAsString[closeIndex:]
 
        start = closeIndex + 1
    else:
        break
 
print(myCodeAsString)
# ACHTUNG: Funktioniert nur wenn keine Wrapping / Nesting von Runden Klammern (())
 
 
 
 
 
print("### Code Ausführen der als String gespeichert ist")
exec(myCodeAsString)
 
 
 
 
 
 
 
 
 
'''
 
s.center(20, "-")     # "---Hallo Welt----"
'''
 
 
myString = 'Hallo Welt'
myNum = "123"
myAlphaNum = "1st"
 
 
 
print("### Teile von Strings via Index (String = Sequenz)")
print(myString[0:5], "\n")
 
 
print("### Prüfung auf Teilstrings via 'in'")
hasHallo    = "Hallo" in myString
print(hasHallo, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung auf Teilstrings am Anfang:")
startsHallo = myString.startswith("Hallo")
print(startsHallo, "\n")
 
 
print("### Prüfung auf Teilstrings am Ende:")
endsWelt = myString.endswith("Welt")
print(endsWelt, "\n")
 
print("\n")
 
 
 
 
 
 
print("### Prüfung ob nur Buchstaben:")
 
hasOnlyLetters = myString.isalpha()
print(hasOnlyLetters, "\n")
 
hasOnlyLetters = myAlphaNum.isalpha()
print(hasOnlyLetters, "\n")
 
print("\n")
 
 
 
 
 
 
print("### Prüfung ob nur Buchstaben und Zahlen:")
 
hasAlphaNum = myAlphaNum.isalnum()
print(hasAlphaNum, "\n")
 
hasAlphaNum = myNum.isalnum()
print(hasAlphaNum, "\n")
 
hasAlphaNum = myAlphaNum.isalnum()
print(hasAlphaNum, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung ob nur Zahlen:")
 
hasOnlyNums = myAlphaNum.isdigit()
print(hasOnlyNums, "\n")
 
hasOnlyNums = myNum.isdigit()
print(hasOnlyNums, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung ob nur Spaces:")
 
mySpace = " "
hasOnlySpaces = mySpace.isspace()
print(hasOnlySpaces, "\n")
print("\n")
 
 
 
 
print("### Text in Großbuchstaben verwandeln:")
 
myString = myString.upper()  
myNum = myNum.upper()  
myAlphaNum = myAlphaNum.upper()  
print(myString)
print(myNum)
print(myAlphaNum)
print("\n")
 
 
 
 
print("### Text in Kleinbuchstaben verwandeln:")
 
myString = myString.lower()  
myNum = myNum.lower()  
myAlphaNum = myAlphaNum.lower()  
print(myString)
print(myNum)
print(myAlphaNum)
 
print("\n")
 
 
 
print("### Anfangsbuchstaben von jedem Wort groß starten:")
 
myString = myString.title()
print(myString)
print("\n")
 
 
 
 
print("### Nur erstes Wort groß starten:")
 
myString = myString.capitalize()
print(myString)
print("\n")
 
 
 
 
print("### Aüßere Leerzeichen (sog. White Spaces) entfernen:")
 
myString = "   " + myString + "   "
myString = myString.strip()
print(myString)
print("\n")
 
 
 
 
print("### Teilstring ersetzen:")
 
myString = myString.replace("Welt", "Jupiter")
print(myString)
print("\n")
 
 
 
 
print("### Teilstring ersetzen:")
 
myString = myString + " Jupiter" + " Jupiter" + " Jupiter"
myString = myString.replace("Welt", "Jupiter", 1).strip()
print(myString)
myString = myString.replace("Welt", "Jupiter").strip()      # Default 3rd arg is all
print(myString)
print("\n")
 
 
 
 
 
myCodeAsString = '''
myString = "  (Hallo Welt)  "
myString = myString.strip()
print(myString)
print("\n")
'''
 
 
print("### Alle 'myString' durch 'ourString' ersetzen:")
myCodeAsString = myCodeAsString.replace("myString", "ourString")
print(myCodeAsString, "\n")
 
 
 
 
print("### Rückgabe des Startindex des ersten Vorkommens")
firstRoundBracket = myCodeAsString.find("(")                
print(firstRoundBracket)
 
print("### Rückgabe -1 wenn nichts gefunden")
firstRoundBracket = myCodeAsString.find("heinzelmännchen")
print(firstRoundBracket)
print("\n")
 
 
 
 
print("### Teilstring innerhalb eines Bereiches finden und ersetzen:")
print("##### Alle Strings innerhalb von () ersetzen")
 
start = 0
while True:
    openIndex = myCodeAsString.find("(", start)
    closeIndex = myCodeAsString.find(")", openIndex)
 
    if openIndex != -1 and closeIndex != -1 and closeIndex > openIndex:
        inside = myCodeAsString[openIndex + 1 : closeIndex].strip()
        if inside:  # nur ersetzen wenn Inhalt zwischen Klammern
            myCodeAsString = myCodeAsString[:openIndex + 1] + "'placeholder'" + myCodeAsString[closeIndex:]
 
        start = closeIndex + 1
    else:
        break
 
print(myCodeAsString)
# ACHTUNG: Funktioniert nur wenn keine Wrapping / Nesting von Runden Klammern (())
 
 
 
 
 
print("### Code Ausführen der als String gespeichert ist")
exec(myCodeAsString)
 
 
 
 
 
 
 
 
 
'''
 
s.center(20, "-")     # "---Hallo Welt----"
'''
 
 
 
myString = 'Hallo Welt'
myNum = "123"
myAlphaNum = "1st"
 
 
 
print("### Teile von Strings via Index (String = Sequenz)")
print(myString[0:5], "\n")
 
 
print("### Prüfung auf Teilstrings via 'in'")
hasHallo    = "Hallo" in myString
print(hasHallo, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung auf Teilstrings am Anfang:")
startsHallo = myString.startswith("Hallo")
print(startsHallo, "\n")
 
 
print("### Prüfung auf Teilstrings am Ende:")
endsWelt = myString.endswith("Welt")
print(endsWelt, "\n")
 
print("\n")
 
 
 
 
 
 
print("### Prüfung ob nur Buchstaben:")
 
hasOnlyLetters = myString.isalpha()
print(hasOnlyLetters, "\n")
 
hasOnlyLetters = myAlphaNum.isalpha()
print(hasOnlyLetters, "\n")
 
print("\n")
 
 
 
 
 
 
print("### Prüfung ob nur Buchstaben und Zahlen:")
 
hasAlphaNum = myAlphaNum.isalnum()
print(hasAlphaNum, "\n")
 
hasAlphaNum = myNum.isalnum()
print(hasAlphaNum, "\n")
 
hasAlphaNum = myAlphaNum.isalnum()
print(hasAlphaNum, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung ob nur Zahlen:")
 
hasOnlyNums = myAlphaNum.isdigit()
print(hasOnlyNums, "\n")
 
hasOnlyNums = myNum.isdigit()
print(hasOnlyNums, "\n")
 
print("\n")
 
 
 
 
 
print("### Prüfung ob nur Spaces:")
 
mySpace = " "
hasOnlySpaces = mySpace.isspace()
print(hasOnlySpaces, "\n")
print("\n")
 
 
 
 
print("### Text in Großbuchstaben verwandeln:")
 
myString = myString.upper()  
myNum = myNum.upper()  
myAlphaNum = myAlphaNum.upper()  
print(myString)
print(myNum)
print(myAlphaNum)
print("\n")
 
 
 
 
print("### Text in Kleinbuchstaben verwandeln:")
 
myString = myString.lower()  
myNum = myNum.lower()  
myAlphaNum = myAlphaNum.lower()  
print(myString)
print(myNum)
print(myAlphaNum)
 
print("\n")
 
 
 
print("### Anfangsbuchstaben von jedem Wort groß starten:")
 
myString = myString.title()
print(myString)
print("\n")
 
 
 
 
print("### Nur erstes Wort groß starten:")
 
myString = myString.capitalize()
print(myString)
print("\n")
 
 
 
 
print("### Aüßere Leerzeichen (sog. White Spaces) entfernen:")
 
myString = "   " + myString + "   "
myString = myString.strip()
print(myString)
print("\n")
 
 
 
 
print("### Teilstring ersetzen:")
 
myString = myString.replace("Welt", "Jupiter")
print(myString)
print("\n")
 
 
 
 
print("### Teilstring ersetzen:")
 
myString = myString + " Jupiter" + " Jupiter" + " Jupiter"
myString = myString.replace("Welt", "Jupiter", 1).strip()
print(myString)
myString = myString.replace("Welt", "Jupiter").strip()      # Default 3rd arg is all
print(myString)
print("\n")
 
 
 
 
 
myCodeAsString = '''
myString = "  (Hallo Welt)  "
myString = myString.strip()
print(myString)
print("\n")
'''
 
 
print("### Alle 'myString' durch 'ourString' ersetzen:")
myCodeAsString = myCodeAsString.replace("myString", "ourString")
print(myCodeAsString, "\n")
 
 
 
 
print("### Rückgabe des Startindex des ersten Vorkommens")
firstRoundBracket = myCodeAsString.find("(")                
print(firstRoundBracket)
 
print("### Rückgabe -1 wenn nichts gefunden")
firstRoundBracket = myCodeAsString.find("heinzelmännchen")
print(firstRoundBracket)
print("\n")
 
 
 
 
print("### Teilstring innerhalb eines Bereiches finden und ersetzen:")
print("##### Alle Strings innerhalb von () ersetzen")
 
start = 0
while True:
    openIndex = myCodeAsString.find("(", start)
    closeIndex = myCodeAsString.find(")", openIndex)
 
    if openIndex != -1 and closeIndex != -1 and closeIndex > openIndex:
        inside = myCodeAsString[openIndex + 1 : closeIndex].strip()
        if inside:  # nur ersetzen wenn Inhalt zwischen Klammern
            myCodeAsString = myCodeAsString[:openIndex + 1] + "'placeholder'" + myCodeAsString[closeIndex:]
 
        start = closeIndex + 1
    else:
        break
 
print(myCodeAsString)
# ACHTUNG: Funktioniert nur wenn keine Wrapping / Nesting von Runden Klammern (())
 
 
 
 
 
print("### Code Ausführen der als String gespeichert ist")
exec(myCodeAsString)
 
 
 
 
 
 
 
 
 
'''
 
s.center(20, "-")     # "---Hallo Welt----"
'''
 
 