userDB = {
    1: {"name": "Arnold", "alter": 21, "hobbies": ["schwimmen", "gaming"]},
    2: {"name": "Burma",  "alter": 22, "hobbies": ["anime", "twitch"]},
    3: {"name": "Christian", "alter": 23, "hobbies": ["muay thai", "fußball"]},
    4: {"name": "Dorothea", "alter": 24, "hobbies": ["poker", "schach"]},
    5: {"name": "Emine", "alter": 25, "hobbies": ["triathlon", "trading"]},
    6: {"name": "Faruk", "alter": 26, "hobbies": ["coding", "gaming"]},
    7: {"name": "Gerda", "alter": 27, "hobbies": ["reiten", "turmspringen"]},
    8: {"name": "Harald", "alter": 28, "hobbies": ["malen", "kochen"]},
    9: {"name": "Ilka", "alter": 29, "hobbies": ["tanzen", "lesen"]},
}
def _readDB():
    _userDB=userDB
    return _userDB
def _printPerLine():
    memDB = _readDB()
    for key,value in userDB.items():
        print(key,value)
def _countUsers():
    memDB=_readDB()
    return len(memDB)
def _averageAge():
    memDB=_readDB()
    _averageAge=0
    for key,value in memDB.items():
        _averageAge +=memDB[key]["alter"]
    _averageAge /=_countUsers()
    return _averageAge

def _deleteUser(userID):
    del userDB[userID]


#########################################
_deleteUser(9)
_printPerLine()
useramt = _countUsers()
print(useramt)
averageAge=_averageAge()
print('averageAge',averageAge)
print(_averageAge())

