# S E T S

# Sets sind Mutable

# Quasi Dictionaries ohne Values
# Sets definieren sich auch mit geschweiften Klammern: {}

# Im Gegensatz zu Dicts sind Sets aber hashbasiert, dh unsortiert (wurde also mit Python 3.7 nicht als sortierte Sequenz umdefiniert)
# D.h. Reihenfolge der Einträge kann sich "willkürlich" ändern =>x auch wenn die Daten gleich bleiben

# HINWEIS: Bei simplen Zahlenfolgen macht sich die Unsortiertheit ggf. noch nicht bemerkbar

# Man darf Tuples in Sets reinlegen, aber keine dicts, keine, sets und keine listen


mySet = {1, 2, 3}
print(mySet)

# DUPLIKATE WERDEN NICHT VERARBEITET !!!!!!!
mySet = {1, 2, 1, 3}
print(mySet) # Sollten Duplikate vorhanden sein, zählt immer nur das erste Vorkommnis (alle danach ignoriert)

# ERGO: Schnellster Weg um Doubles aus Liosten oder Tuples zu entfernen is z.B. Set-Casting
myTuple = (1, 2, 2, 1, 3, 4, 3, 3, 5, 4, 4, 3, 2, 1)
mySet = set(myTuple)
myTuple = tuple(mySet)
print(myTuple)

mySet.discard(1)           # Entfernt x, kein Fehler wenn x fehlt
print(mySet, "\n")

print(mySet.pop())          # Entfernt & gibt ein zufälliges Element zurück, da keine Sortierung
print(mySet, "\n")

mySet.add("🐈")             # Element x hinzufügen
mySet.add("😺") 
mySet.add("Katze") 
mySet.add("Cat") 
#mySet.add([]) 
print(mySet, "\n")

mySet.clear()               # Set leeren
print(mySet, "\n")

print(mySet)



myString = "HalliiHalloooooo"
mySet = set(myString)
myString = str(mySet)
print(myString)
print("\n\n")
myString = "HalloHallo"
myHash = hash(myString)
print(myHash)



# Welche Methoden existieren z.B. nicht auf Sets:

'''
.append()
.insert()
.sort()
.reverse()
.index()
'''

# Welche Methoden existieren, z.B.:
'''
.remove()
.add()
.discard()
.clear()
. . .  etwaige andere Methode die nicht direkt mit Sequenzen wie Listen etc zusammenhängen
'''