'''
import mymodule
print("myVar", mymodule.myVar)
result = mymodule.myFunction(50, 25)
print("result", result)
'''

'''
import mymodule as mm
print("myVar", mm.myVar)
result = mm.myFunction(50, 25)
print("result", result)
'''


'''
from mymodule import *
print("myVar", myVar)
result = myFunction(50, 25)
print("result", result)
'''


'''
from mymodule import myVar, myFunction
print("myVar", myVar)
result = myFunction(50, 25)
print("result", result)

'''

'''

from module import mymodule as mm
print("myVar", mm.myVar)
result = mm.myFunction(50, 25)
print("result", result)
'''



from module.mymodule import *
print("myVar", myVar)
result = myFunction(50, 25)
print("result", result)
