
import random 

# Achtung: Dateiname darf nicht Name der Library sein

# Zufallszahl zwischen 1 und 100 generieren:
randomInt = random.randint(1, 100)          # zweites Argument ist inklusive (nicht wie bei range() wo es exklusive ist)
print("randomInt", randomInt, "\n")

# Zufallsitem aus einer Sequence nehmen (außer Sets):
myList = ["a", "b", "c", "d", "d", "f", "g"]
randomChoice = random.choice(myList)
print("randomChoice", randomChoice, "\n")

# Zahl zwischen 0 und 1:
randomRandom = random.random()
print("randomRandom", randomRandom, "\n")

# Eine Wahrscheinlichkeit von 0.5 generieren
prob05 = random.random() > 0.5
print("prob05", prob05, "\n")

# Eine Wahrscheinlichkeit von 0.25 generieren
prob025 = random.random() < 0.25
print("prob025", prob025, "\n")

# Eine Wahrscheinlichkeit von 0.75 generieren
rand = random.random()
if rand < 0.75:
    print(True, rand)
else:
    print(False, rand)

# Eine Float Random innerhalb selbst gewählter Range generieren:
randFloat = random.uniform(1.5, 5.5)
print("randFloat", randFloat, "\n")

# Zufallszahl innerhalb Range generieren mit Schrittweite (z.B. für Even oder Odd)
randomRange = random.randrange(0, 10, 2)
print("randomRange", randomRange, "\n")