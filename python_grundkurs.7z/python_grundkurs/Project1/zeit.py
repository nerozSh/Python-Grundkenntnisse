import time 
#
# ACHTUNG: Dateiname darf nicht dem Namen einer Python-nativen Library entsprechen (stdlib Error)
    # time.py => Problem
    # z.B. zeit.py => kein Problem

# Der Unix-Timestamp zählt die Sekunden seit dem 1. Januar 1970, 00:00:00 UTC (Universal Centralised/Standard Time)
    # => auch Epoch genannt
# Standardwert zur Zeitmessing in vielen Systemen



# Ziel: Kleines Performanztestbeispiel mit Vergleich zum zählen sekündlichen Pausen
# Unterstellung: Endzeit minus Startzeit ist größer als gezählte Sekunden
# Grund: Zwischen den kumulierten (gezählten) Sekunden werden Prozesse ausgeführt

interval =1
countsecs =0

start=time.gmtime()        #Gib uns die gegenwärtige Zeit,wenn wir kein Argument an die gmtime() Methode übergeben
print("start",start)
print("jahr",start.tm_year)
print("Monat",start.tm_mon)
print("Tag",start.tm_mday)
print("Stunde",start.tm_hour)
print("sekunden",start.tm_sec)
print("wochentag",start.tm_wday)
print("jahresTag",start.tm_yday)

startMS=int(time.time()*1000) #Millisekunden zur gegenwärtige Zeit erhalten (=Sekunden * 1000)
print("StartMS",startMS)
print("\n")
for i in range(1,11):
    time.sleep(interval)
    countsecs += interval
    print(countsecs)
end=time.gmtime()
endMs=int(time.time()*1000)
diff = endMs - startMS
print("ResponceTime",diff)
########################################################################################################
StartUTC =time.gmtime(startMS / 1000)
print("StartUTC,",StartUTC, "\n")
StartISO=time.strftime("%Y-%m-%d ==>>%H:%M:%S %z")
print(StartISO)
# Fazit: Für Performanztests eignet sich das reine Kumulieren NICHT
# Sondern wir müssen vor und nach dem Prozess die gegenwärtige Zeit in !Millisekunden! vergelichen um eine genaue Aussage treffen zukönnen 


# INFO:

# time.sleep() hat versch. Anwendungsfälle, Bsp:
    # Um dem für den User einen Countdown zu generieren und im Anshcluss im Frontend (zu z.B. Website / App via JS) anzuzeigen
    # bei iteraiven API-Calls, um kein Rate-Limit auferlegt zu bekommen
    # bei RPC (Remote-Procedure ...) kein Rate-Limit auferlegt zu bekommen
    # um auf Daten zu warten
    # um beim Scraping zusätzlich auf das Vorhandensein von Elementen zu warten


startISO = time.strftime("%d.%m.%Y %H:%M:%S %z")            # ohne 2ten Parameter ist Defaulttime = JETZT, sonst die Zeit die wir als 2ten Parameter übergeben => je nach Basis ectl. =>x Abweichung zu UTC bzw. Local Time

# ERGÄNZUNG ZUR ZEITUMRECHNUNG

from datetime import datetime
from zoneinfo import ZoneInfo

utc_now = datetime.utcnow().replace(tzinfo=ZoneInfo("UTC"))
local = utc_now.astimezone(ZoneInfo("Europe/Berlin"))

print("Ergänzung")
print("Timestamp", local.timestamp())                           # Unix-Timestamp (Sekunden)
print("ISO", local.isoformat())                                 # ISO 8601 Format
print("Stringified", local.strftime("%d.%m.%Y %H:%M:%S"))       # z.B. für DE

