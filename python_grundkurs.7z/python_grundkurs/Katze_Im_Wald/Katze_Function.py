import sys 
# ------------                   GAME STATE                     --------------
State ={
    "Level":"level1",
    "Inventory": []
}
# ########################### F U N C T I O N S######################################################
def changeLevel(newLevel):
    # WECHSELT ZU EINEM NEUEN  LEVEL
    State["Level"] = newLevel
def addItem(item):
    # FÜGT EINEM GEGENSTAND DEM INVENTOR HINZU
    if item not in State["Inventory"]:
        State["Inventory"].append(item)
def showInventor():
    #ZEIGT DEN AKTUELLEN INHALT DES INVENTORS
    s = State["Inventory"]
    if s :
        print("Dein Inventory :",",",",".join(s))
    else:
        print("DEin Inventory ist Leer.")
def askContinue(nextLevel):
    # FRAGT DER SPIELER OB ER WEITER WECHSELN MÖCHTE ;ERLAUBT NUR WENN DEN INVENTOR NICHT LEER IST 
    showInventor()
    choice = input ("Möchtest du zum nächsten Level Wechsel? (yes/no)🐱::")
    if choice !="yes":
       endGame("du hast dich entscheiden aufzuhören .Leider endet das Abenteur hier ")
    if  not State["Inventory"]:
       endGame("dein Inventory ist Leer ...Leider du kannst nicht weiterspielen")
    changeLevel(nextLevel)
def endGame(reason):
    #BEENDET DAS SPIEL MIT EINER NACHRICHT
    print(f"{reason}")
    print("------------GAME OVER-------------")
    sys.exit()
#################################### L E V E L S #########################################################
def level1():
    print(" Du bist eine Katze im Wald und Siehst eine Walnss auf dem Boden")
    choice = input ("Möchtest du die Walnuss aufheben ????(yes / no )🐱 ::").strip().lower()
    if choice == "yes":
        addItem("Walnuss")
        print("Super !!!!!du Hast Walnuss deinem Inventory hingefügt.")
    else:
        print("Du hast nichts aufgehoben.")
    askContinue("level2")
def level2():
    print("Du hörst das Plätschern eines Baches. vor dir steht eine Wasserflasche.")
    choice = input("Möchtest du die Wasserflasche nehmen?(yes / no)🐱::").strip().lower()
    if choice == "yes":
        addItem("Wasserflasche")
        print("cool du hast Wasserflasche dein Inventory hinzufügt")
    else:
        print("Du gesht ohne Wasser weiter.")
    askContinue("level3")
def level3():
    print("Dub gehst weiter durch den Wald ,als plötzlich ein hungriger Wolf vor dir auftaucht!!!.")
    print("der Wolf sieht dich an und beginnt , sich dir zu nähern.du mmusst schnell handeln!!!!")
    choice =input("Möchtest du dem Rehkitz helfen ?(fliehen / verstecken)🐱::").strip().lower()
    if choice=="fliehen":
        print("Du drehst dich um und rennst so schnell du kannst.Der Wolf folgt dich ,aber du schaffst es,ihn abzuhängen ")
        addItem("Flucht vor dem Wolf")
        print("Du hast <<Flucht vor dem Wolf>> dein Inventory hinzufügt")
    elif choice=="verstecken":
        print("Du springst in einem Busch und hoffst ,dass der Wolf dich nicht bemerkt . Glücklischerweise verliert er schnell die Spur ")
        addItem("verstekt vor dem Wolf")
        print("Du hast <<versteckt vor dem Wolf >> dein Inventory hinzufügt")
    else :
        print("Du zögert zu lange ,der Wolf kommt näher ,aber schaffst es noch ,ihm zu entkommen!!!")
        
    askContinue("level4")
def level4():
    print("Du erreicht eine weise Eule auf einem HÖgel")
    print("Die Eule stellt dir ein Rätsel:was zerbricht ,wenn man es ausspricht?")
    answer = input("Deine Antwort des Rätsels:🐱::").strip().lower()
    if answer=="stille":
        print("Die Eule ist beindrickt und gibt dir einem Schlüssel nach Hause ")
        addItem("Schlüssel nach Huase")
    else:
        print("Falsche Antwort ,aber die Eule lässt dich weiter .")
    askContinue("end")
def levelEnd():
    print("Ende des Spieles <<Glückwunsch>>!!!!!!!!!!!! die Katze ist zu Hause ")
    showInventor()
    print("🐱🐱🐱🐱🐱🐱")
    sys.exit()