from Katze_Function import State, level1, level2, level3, level4, levelEnd, endGame



def main():
    print("Katzenhilfen im Wald - Vier Stufen mit INventory-Check")
  
    while True:
        currentLevel =State["Level"]
        if currentLevel == "level1":
          level1()
        elif currentLevel=="level2": 
          level2()
        elif currentLevel=="level3":
          level3()
        elif currentLevel=="level4":
          level4()
        elif currentLevel=="end":
          levelEnd()
        else:
          endGame(f"{currentLevel}")
          


if __name__ == "__main__":
    main()