import tkinter as tk 
window = tk.Tk()
window.title("Grid")
sWidth=480
sHeight=768
sPosx=512
sPosy=50
window.geometry(f"{sWidth}x{sHeight}+{sPosx}+{sPosy}")
window.columnconfigure(0,weight=1)
window.columnconfigure(1,weight=1)
#window.rowconfigure(0,weight=1)
#window.rowconfigure(1,weight=1)
width_=window.winfo_width()
print("_width",width_)
#window.resizable(False,False)
window.update()



def upSizeWindow():
    global sWidth
    global sHeight
    #sWidth +=100
    #sHeight+=100
    sWidth=int(sWidth * float(entry1.get()))
    sHeight=int(sHeight * float(entry1.get()))
    window.geometry(f"{sWidth}x{sHeight}+{sPosx}+{sPosy}")
    window.update()
    
def downSizeWindow():
    global sWidth
    global sHeight
    #sWidth -=100
    #sHeight-=100
    sWidth=int(sWidth * float(entry1.get()))
    sHeight=int(sHeight * float(entry1.get()))
    window.geometry(f"{sWidth}x{sHeight}+{sPosx}+{sPosy}")
    window.update()
    
label1 = tk.Label(text="L F G")
button1= tk.Button(text="upSize",command = upSizeWindow) 
button2=tk.Button(text="downSize",command = downSizeWindow)
entry1=tk.Entry(window)
label1.grid(row=0,column=0,padx=0,pady=0,columnspan=2)
entry1.grid(row=1,column=0,padx=0,pady=0,columnspan=2)
button1.grid(row=2,column=0,padx=(5,5),pady=0,sticky="ew")
button2.grid(row=2,column=1,padx=(5,5),pady=0,sticky="ew")












###################
tk.mainloop()
upSizeWindow()
downSizeWindow()