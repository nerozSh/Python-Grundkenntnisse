import tkinter as tk
import tkinter.messagebox

# Initiiere hier für die Varible 'app' Eine Tkinter Objektinstanz
# Gebe dem GUI Fenster für das Betriebssystem hier einen Titel
# Stelle folgende Fensterparameter hier ein: 400px Breite, 300px Höhe, Position 600px von links, 200px von oben
# Friere die Größe des Fenster hier ein
app = tk.Tk()
app.title("BMI")
sWidth=400
sHeight=300
xPosx=600
yPosy=200
app.geometry (f"{sWidth}x{sHeight}+{xPosx}+{yPosy}")
app.resizable(False, False)
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


def clearInputs():
    confirm = tkinter.messagebox.askyesnocancel(
        title = "Eingaben löschen",
        message = "Wirklich leeren?"
    )
    if confirm:
        entry_gewicht.delete(0, tkinter.END)
        entry_groesse.delete(0, tkinter.END)
        #Setze den Text von 'label_bmi_result' hier = 0
       # label_bmi_reesult=tk.label(text="0")
        label_bmi_result.config(text="0")

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
def calc_bmi():
    category = ""
    gewicht = 0
    groesse = 0
    # Fetche das Gewicht aus dem jew. Entry Feld und caste damit die Berechnung gemacht werden kann
    gewicht = float(entry_gewicht.get())
    # Fetche die Größe aus dem jew. Entry Feld und caste damit die Berechnung gemacht werden kann
    groesse = float(entry_groesse.get())

    bmi = gewicht / ( (groesse / 100)  ** 2)


    # Ist der BMI unter 18.5 setze 'category' = "Untergewicht"
    if bmi <18.5 :
        category = "Untergewicht"
    
    # Ist der BMI unter 25 setze 'category' = "Normalgewicht"
    elif bmi <=25:
        category = "Normalgewicht"
    # Ist der BMI unter 30 setze 'category' = "Übergewicht"
    elif bmi <= 30:
        category = "Übergewicht"
    # Ansonsten setze 'category' = "Adipositas"
    else:
        category = "Adipositas"
    # Zeige im Text des Labels 'label_bmi_result' den BMI an 
    label_bmi_result["text"] = f"{bmi:.1f} ({category})"
   # label_bmi_result=tk.Label(text="f{Bmi}{category}")
   # label_bmi_result.config(text=f" {bmi:.2f} {category}")
#except ValueError:
#tk.messagebox.showerror("Fehler", "Bitte gültige Zahlen eingeben.")
#----------------------------------------------------------------------
frame =tk.Frame(app,relief="raised",bd=2)
frame.pack(pady=10)
# Buttons
label_gewicht = tk.Label(frame,text="Gewicht(Kg):")
label_gewicht.pack(fill="x",padx=10,pady=5)
entry_gewicht = tk.Entry(frame)
entry_gewicht.pack(fill="x",padx=10)
label_groesse = tk.Label(frame,text="Größe(cm)")
label_groesse.pack(fill="x",padx=10,pady=5)
entry_groesse = tk.Entry(frame)
entry_groesse.pack(fill="x",padx=10,pady=5)
label_result  = tk.Label(frame)
label_result.pack(fill="x",padx=10)
label_bmi_result =tk.Label(frame)
label_bmi_result.pack(fill="x",padx=10)

# Erstelle hier einen Button 'btn_clear' mit dem Text "BMI:" und dem 'frame' als Parent
# Erstelle hier einen Button 'btn_calc' mit dem Text "BMI:" und dem 'frame' als Parent
# Erstelle hier ein Label Element 'label_bmi_result' mit dem 'frame' als Parent

btn_calc = tk.Button(frame,text="BMI",command=calc_bmi)
btn_clear = tk.Button(frame,text="Clear",command=clearInputs)



# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
btn_calc.pack(padx=(10,10),pady=(10,10),fill="x")
btn_clear.pack(padx=(10,10),pady=(10,10),fill="x")

#-----------------------------------------------------------------------------
app.mainloop()