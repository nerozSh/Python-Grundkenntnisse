import tkinter
tk =tkinter.Tk()

#Funktionsbereich
a=0
def _button1():
    global a
    a += 1
    print(f"button pressed. Value = {a}")



#Erzeugungsbereich:Hier ertellen wir GUI Elemente
label1 =tkinter.Label(text="Mein Label")
button1=tkinter.Button(text="Klick",command=_button1)
#button2=tkinter.Button(text="Klick",command=_button1)

#-------------------------------------------------------------------------
#Plazierungsbereich:hier definieren wir die Position der oben erstellen GUI elemente
#Platzierung via pack()Methode :eher für eindimensionale
#--------------------------------------------------------------------------
#expand=1   #Zentierung auf der Queraches
#bei side ="left":::Anordnung des Elementes an der linken Seite des Parent Elementes (hier das Fenster)
    #Achtung
#
#
#
#
button1.pack(fill="both",expand=1) 
#button2.pack(side="left",fill="both") 


#Main loop
tk.mainloop() #=>Hält Gui Instens aufrecht
#Errors 