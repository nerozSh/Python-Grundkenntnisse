import tkinter as tk                # Import der tkinter Code Bibliothek und Definierung einer Abkürzung bei Abruf: tk

window = tk.Tk()                    # via Tk() die Objektinstanz für die GUI erstellen (Graphical User Interface)
window.title("Grid")                # Erscheint oben in dem Fenster dass von Betiebssystem gemanaged wird


def getScreenSize():                    # Helper Funktion, um tatsächliche Bildschirmgröße des Gerätes von Betriebssystem zu erhalten
    root = tk.Tk()                      # GUI ist bei Objektinstanzierung by default == Bildschirmgröße
    root.withdraw()                     # Die Helper-Instanz nicht als genutze Main Instanz verwendet sondern von Window Manager "vergessen" lassen
    width = root.winfo_screenwidth()    # Fensterbreite von der Helperinstanz fetchen (Default = Tatsächliche Bildschirmbreite)
    height = root.winfo_screenheight()  # dito für Höhe
    root.destroy()                      # Helper-Instanz eliminieren (aus Cache entfernen, d.h. "virtuelle" Instanz beenden)
    return width, height                # breite und höhe in einem Tuple ausgeben


myScreen = getScreenSize()          # tatsächliche Bildschirmgröße aus obiger Funktion entgegennehmen
myScreenWidth = myScreen[0]         # Entpacken:  lassen wir statisch damit wir immer unseren Gerätebildschirm kennen
myScreenHeight = myScreen[1]        # dito


sWidth = myScreenWidth              # Wert den wir für die Manupilation unserer GUI-Größe nutzen
sHeight = myScreenHeight            # dito
sPosX = 0                           # Werte für GUI Position-X initiieren am linken Bildschirmrand 
sPosY = 0                           # Werte für GUI Position-Y initiieren am oberen Bildschirmrand 

window.geometry(f"{sWidth}x{sHeight}+{sPosX}+{sPosY}")   # Fensterdimensionen und Positionen initiieren => width x height + posx + posy
window.columnconfigure(0, weight=1)                      # dynamische breite für Spalte1 von Grid (damit reponsive)
window.columnconfigure(1, weight=1)                      # dynamische breite für Spalte2 von Grid (damit reponsive)
#window.rowconfigure(0, weight=1)                        # dito für Zeilen: eher unpraktibel
#window.rowconfigure(1, weight=1)                        # dito für Zeilen: eher unpraktibel
#window.resizable(False, False)                          # Fenstergröße einfrieren
window.update()                                          # Alle Änderungen zwischen vorherigem und jetztigem Mainloop aktualisieren


############################################################################

# BEREICH: FUNKTIONEN

def sizeWindow(op: str):                                            # FUnktion für Berechnung der neuen Fenstergröße

    global sWidth; global sHeight; global window                    # Mit semicolon mehere Code Zeilen in eine scheeiben
    
    if entry1.get():                                                # Nur Ausführen, wenn User Eingabe im Inputfeld gemacht hat (normalerweise mehr Error-Handling ratsam)

        # Siehe mehr Hinweise zu eval() unten *  
        sWidth = int(eval(f"{sWidth} {op} {entry1.get()}"))         # neue GUI-Breite berechnen: alte GUI-Breite * oder / Usereingabe
        sHeight = int(eval(f"{sHeight} {op} {entry1.get()}"))       # neue GUI-Höhe berechnen: alte GUI-Breite * oder / Usereingabe   
        print(sWidth, "x", sWidth)                                  # neue Aspect-Ratio der GUI in Konsole ausgeben

        if sWidth >= myScreenWidth: sWidth = myScreenWidth          # wenn GUI breiter als Screen   dann GUI so breit wie Screen setzen
        if sHeight >= myScreenHeight: sHeight = myScreenHeight      # wenn GUI höher als Screen     dann GUI so hoch wie Screen setzen
        if sWidth <= 400: sWidth = 400                              # wenn GUI schmaler als 400px   dann GUI auf 400 setzen
        if sHeight <= 400: sHeight = 400                            # wenn GUI flacher als 400px    dann GUI auf 400 setzen

        sPosX = int((myScreenWidth - sWidth) / 2)                   # Differenz aus Screenbreite und GUI-Breite = Verfügbarer Restplatz / 2 = StartPosition der GUI vom linken Bildschirmrand 
        window.geometry(f"{sWidth}x{sHeight}+{sPosX}+{sPosY}")      # Neue GUI Werte {breite, höhe, pos-x, pos-y} in gemoetry() methode einsetzen zur Anpassung des Fensters
        window.update()                                             # Fenster Aktualisieren => ganz unten der tk.mainloop() für Script bei jeder GUI-relevanten User-Interkation erneut aus, z.B. Klick auf Button
        output = f"{sWidth}x{sHeight}"                              # Output wert (Aspect Ration des Fensters) aesthetisch formatieren
        label2["text"]= str(output)                                 # Den Output wert in den Text des Labels einsetzen, um für User sichtbar zu machen
    
    else:                                                           # WENN User keine Eingabe gemacht hat
        label2["text"] = "Not a valid input: Please type and Int or Float"  # ==> DANN: Fallback-Text als Ausgabe 

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

def downWindow(): sizeWindow("/")       # Handlerfunktionen, die den richtien Rechenoperation zu Fensterverkleinerung an die funktion mit der Berechnungslogik übergibt
def upsizeWindow(): sizeWindow("*")     # dito


#############################################################################

# BEREICH: ELEMENTE ERZEUGEN (und basic funktionalitäten definieren)

label1 = tk.Label(window, text="L F G")                                     # Textfeld, zB. Überschrift
entry1 = tk.Entry(window)                                                   # Eingabefeld für User
button1 = tk.Button(window, text="DOWNSIZE", command=downWindow)            # Button der die Vermittlerfunktion für Downsizing aufruft welche die Berechnungsfunktion aufruft
button2 = tk.Button(window, text="UPSIZE", command=upsizeWindow)            # "                 dito              " Upsizing   "           dito         "                        
label2 = tk.Label(window, text="Please Type a Factor for Window Sizing")    # Textfeld: Textwert is über label2["text"] manipuliertbar

# HINWEIS: Als ersres Argument übergeben wir window, da das Fenster das Parent-Element der Elemente ist
# HINWEIS: Children erben vom Parent, z.B. kann man Position des Parent verändern und alle Children bewegen sich mit
# HINWEIS: Das Parent-Elemente ist by default das GUI-Fenster: Wir können aber auch ein anderes Parent festlegen (z.B. .Frame())

#############################################################################

# BEREICH: ELEMENTE POSITIONIEREN
# Mit Grid ordnen wir die oben erstellten Elemente in einem zweidimensionalem Raster an (quasi wie Tabellenstruktur)
# Siehe genauere Hinweise zu den einzelnen Argumenten unten **

label1.grid(row = 0, column = 0, padx=0, pady=0, columnspan=2)          # row=0 (Reihe1), column=0 (Spalte1) columnspan=2 (Feld verwendet zwei Spalten ab column=0) 
entry1.grid(row = 1, column = 0, padx=0, pady=0, columnspan=2)          # row=1 (Reihe2) ..... dito
button1.grid(row = 2, column = 0, padx=(5, 5), pady=0, sticky="ew")     # row=2 (Reihe3) ... padx=(5, 5) auf X-Achse je 5 Bildschirmeinheiten Abstand rechts und links von Element Außenseite
button2.grid(row = 2, column = 1, padx=(5, 5), pady=0, sticky="ew")     # dito: button2
label2.grid(row = 3, column = 0, padx=0, pady=0, columnspan=2)          # row=3 (Reihe4)   ... siehe label1 für dito


####################################################################################


# MAINLOOP ! Führt das gesamte Script von oben nach unten jedes Mal aus, wenn Benutzer interagiert, z.B. Button Klick 
window.mainloop()       # Immer letzte Codezeile in tkinter       

####################################################################################


# * HINWEIS ZU EVAL:
    # a = eval("5 * 10") => Das macht Eval in der Theorie: Eine String als Rechnung ausführen: Ergebnis ist also Zahl (wenn Werte in Eval Fähig zur Berechnung
    # eval() ermöglicht es eine Rechenoperation die wir als String schreiben auszuführen
    # d.h. wir können eine f-String verwenden um innerhalb von eval() Strings mit Zahlen in einer Operation zu schreiben
    # on der variable op hatten wir den Rechenoperation (* oder /) aus den buttonfuntionen übergeben
    # Wir haben uns also etwaige if / else statements gespart
    # ACHTUNG: eval() ist mit Vorsicht zu genießen aus Sicherheitshgründen !!!!!

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# ** Weitere Hinweise zu Argumenten bei der Positionierung von Elementen via .grid()
# padx = Abstand des Elementes zur Linken inneren Seite des Elternelementes (hier Fenster)
# pady = Abstand des Elementes zur Oberen inneren Seite des Elternelementes (hier Fenster) 
# Keine negativen Werte erlaubt !

# parameter row und parameter colum basierend auf zeilen- bzw. spalten indizies! d.h 0 = anfang
# rowspann und columnspan sind quasi längeneinheiten wie bei len auf listen, d.h. 1 = 1


# Yayyy :-)