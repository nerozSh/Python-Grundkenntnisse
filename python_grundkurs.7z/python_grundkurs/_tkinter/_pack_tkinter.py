import tkinter
tk =tkinter.Tk()

#Funktionsbereich
def _button1():
    print("button pressed")
label1 =tkinter.Label(text="Mein Label")
#
#Erzeugungsbereich:Hier ertellen wir Gui Elemente

#-------------------------------------------------------------------------
#Plazierungsbereich:hier definieren wir die Position der oben erstellen GUI elemente
#Platzierung via pack()Methode :eher für eindimensionale
#--------------------------------------------------------------------------
label1.pack(expand=1) #expand=1


#Main loop
tk.mainloop() #=>Hält Gui Instens aufrecht
#Errors 